#include "global_planning.h"


PLANNING::PLANNING()
{
    SetParams();
    if(is_lane_on)
        LineArrayPub = nh.advertise<visualization_msgs::MarkerArray>("line_array",1);
    if(is_node_on)
        MapPointsPub = nh.advertise<visualization_msgs::Marker>("nodes",1);
    if(is_link_on)
        LinkArrayPub = nh.advertise<visualization_msgs::MarkerArray>("link_array",1);
    if(is_path_on){
        PathArrayPub = nh.advertise<visualization_msgs::Marker>("/globalPath",1);
        OffsetMapPub = nh.advertise<geometry_msgs::Point>("/OffsetMap",1);
    }

    // < Subscriber >
    static ros::Subscriber GpsPositionSub = nh.subscribe("/gps/fix",1,&PLANNING::GpsCallback,this);
    static ros::Subscriber GpsHeadingSub = nh.subscribe("/gps/navpvt",1,&PLANNING::GpsHeadingCallback,this);
    static ros::Subscriber RvizPositionSub = nh.subscribe("/initialpose",1,&PLANNING::RvizNavStartCallback,this);
    static ros::Subscriber RvizEndSub = nh.subscribe("/move_base_simple/goal",1, &PLANNING::GlobalPathHandler,this);

    ros::Duration(1.0).sleep();

    OpenLaneSHP();
    OpenLinkSHP();
    OpenNodeSHP();
}

PLANNING::~PLANNING(){
}

void PLANNING::SetParams()
{
    nh = ros::NodeHandle("~");
    is_simul_on = false;
    nh.param("/rviz_on/is_link_on", is_link_on, true);
    nh.param("/rviz_on/is_node_on", is_node_on, true);
    nh.param("/rviz_on/is_lane_on", is_lane_on, true);
    nh.param("/rviz_on/is_path_on", is_path_on, true);

    nh.param<std::string>("/shp/lane", lane_shp, "/home/jsg/AutoCar/Material/[0] HdMap/HD_Map/KIAPI Vector HD Map/A1_LANE/A1_LANE.shp");
    nh.param<std::string>("/shp/link", link_shp, "/home/jsg/AutoCar/Material/[0] HdMap/HD_Map/KIAPI Vector HD Map/A3_LINK/A3_LINK.shp");
    nh.param<std::string>("/shp/node", node_shp, "/home/jsg/AutoCar/Material/[0] HdMap/HD_Map/KIAPI Vector HD Map/C1_NODE/C1_NODE.shp");

    nh.param<std::string>("/layer/lane", layer_lane, "A1_LANE");
    nh.param<std::string>("/layer/link", layer_link, "A3_LINK");
    nh.param<std::string>("/layer/node", layer_node, "C1_NODE");

    nh.param("/link/id", shp_link_id, 0);
    nh.param("/link/from_node", shp_link_from_node, 1);
    nh.param("/link/to_node", shp_link_to_node, 2);
    nh.param("/link/length", shp_link_length, 3);
    nh.param("/link/speed", shp_link_speed, 6);
    nh.param("/link/left_link", shp_link_left_link, 16);
    nh.param("/link/right_link", shp_link_right_link, 17);
    nh.param("/link/next_link", shp_link_next_link, 18);

    nh.param("/node/id", shp_node_id, 0);
    nh.param("/node/next_link", shp_node_next_link, 8);
    nh.param("/node/prev_link", shp_node_prev_link, 9);

    nh.param<double>("/lane_change/weight", weight, 4);
    nh.param<double>("/lane_change/length_lane_changed", length_lane_changed, 50);

    ROS_INFO("LANE_SHAPEFILE : \n%s\n", lane_shp.c_str());
    ROS_INFO("LINK_SHAPEFILE : \n%s\n", link_shp.c_str());
    ROS_INFO("NODE_SHAPEFILE : \n%s\n", node_shp.c_str());
    ROS_INFO("Layer:\n%s  %s  %s  \n", layer_lane.c_str(), layer_link.c_str(), layer_node.c_str());
}

/** Open shape file of lane */
void PLANNING::OpenLaneSHP(){

	OGRRegisterAll();
	vector<string> StringLaneVector;
    GDALDataset *poDS = static_cast<GDALDataset*>( GDALOpenEx( lane_shp.c_str(), GDAL_OF_VECTOR, NULL, NULL, NULL ));

    if( poDS == NULL ){
        printf( "Open failed.\n" );
        exit( 1 );}

    OGRLayer  *poLayer = poDS->GetLayerByName( layer_lane.c_str() );
    OGRFeatureDefn *poFDefn = poLayer->GetLayerDefn();
    poLayer->ResetReading();
    OGRFeature *poFeature;
    while( (poFeature = poLayer->GetNextFeature()) != NULL ){
		char *pszWKT = NULL;
        OGRGeometry *poGeometry = poFeature->GetGeometryRef();
        if( poGeometry != NULL && wkbFlatten(poGeometry->getGeometryType()) == wkbLineString ){
           	poGeometry->exportToWkt(&pszWKT);
           	StringLaneVector.push_back(pszWKT);
           	// printf("%s\n", pszWKT);
           	CPLFree(pszWKT);
        }
        else{
            printf( "LANE : no point geometry\n" );}

        OGRFeature::DestroyFeature( poFeature );
    }
    GDALClose( poDS );

    InitializeRvizLaneArray(StringLaneVector.size());
    ParsingLaneGeometry(StringLaneVector);

    if(is_lane_on)
	   LineArrayPub.publish(LineArray);

    ROS_INFO("Received Lane : %d", LineArray.markers.size());
}

void PLANNING::InitializeRvizLaneArray(int len){
    LineArray.markers.resize(len);
    for(unsigned int i=0; i<len; i++){
        LineArray.markers[i].header.frame_id = "base_link";
        LineArray.markers[i].header.stamp = ros::Time::now();
        LineArray.markers[i].action = visualization_msgs::Marker::ADD;
        LineArray.markers[i].pose.orientation.w = 1.0;
        LineArray.markers[i].id = i;
        LineArray.markers[i].type = visualization_msgs::Marker::LINE_STRIP;
        LineArray.markers[i].scale.x = 0.3;
        LineArray.markers[i].color.r = 1.0;
        LineArray.markers[i].color.g = 1.0;
        LineArray.markers[i].color.b = 1.0;
        LineArray.markers[i].color.a = 1.0;     
    }   
}

void PLANNING::ParsingLaneGeometry(vector<string> StringLaneVector){
    
    geometry_msgs::Point LanePoint;
    string geometry_str;
    string str;
    unsigned long comma;
    unsigned long space;
    vector<geometry_msgs::Point> LaneGeoVector;
    
    comma = StringLaneVector[0].find("(");
    geometry_str = StringLaneVector[0].substr(comma+1);
    comma = geometry_str.find(" ");
    str = geometry_str.substr(0,comma);
    OffsetMapX = atof(str.c_str());
    geometry_str = geometry_str.substr(comma+1);
    comma = geometry_str.find(" ");
    str = geometry_str.substr(0,comma);
    OffsetMapY = atof(str.c_str());

    OffsetMap.x = OffsetMapX;
    OffsetMap.y = OffsetMapY;

    OffsetMapPub.publish(OffsetMap);


    for(int i=0; i<StringLaneVector.size(); i++){
        geometry_str = StringLaneVector[i];
        comma = geometry_str.find("(");
        geometry_str = geometry_str.substr(comma+1);

        while(geometry_str.find(",") != string::npos){
            comma = geometry_str.find(",");
            str = geometry_str.substr(0,comma);
            space = str.find(" ");
            LanePoint.x = atof(str.substr(0,space).c_str());
            str = str.substr(space+1);
            space = str.find(" ");
            LanePoint.y = atof(str.substr(0,space).c_str());
            LanePoint.z = 0;
            LaneGeoVector.push_back(LanePoint);
            geometry_str = geometry_str.substr(comma+1);

        }
        space = geometry_str.find(" ");
        LanePoint.x = atof(geometry_str.substr(0,space).c_str()) ;
        geometry_str = geometry_str.substr(space+1);
        space = geometry_str.find(" ");
        LanePoint.y = atof(geometry_str.substr(0,space).c_str());
        LanePoint.z = 0;
        LaneGeoVector.push_back(LanePoint);
        LineArray.markers[i].points.resize(LaneGeoVector.size());

        for(int j = 0; j< LaneGeoVector.size(); j++){
            LaneGeoVector[j].x = LaneGeoVector[j].x - OffsetMapX;
            LaneGeoVector[j].y = LaneGeoVector[j].y - OffsetMapY;
            LineArray.markers[i].points[j] = LaneGeoVector[j];

        }
        LaneGeoVector.clear();
    }
}

string PLANNING::ParsingToString (OGRFieldDefn *poFieldDefn, OGRFeature *poFeature, int iField){

    string str = "";
    switch( poFieldDefn->GetType() )
    {
        case OFTInteger:
            // printf( "%d,", poFeature->GetFieldAsInteger( iField ) );
            str.append( to_string( poFeature->GetFieldAsInteger(iField) ) );
            break;
        case OFTInteger64:
            // printf( CPL_FRMT_GIB ",", poFeature->GetFieldAsInteger64( iField ) );
            str.append( to_string( poFeature->GetFieldAsInteger64(iField) ) );
            break;
        case OFTReal:
            // printf( "%.3f,", poFeature->GetFieldAsDouble(iField) );
            str.append( to_string( poFeature->GetFieldAsDouble(iField) ) );
            break;
        case OFTString:
            // printf( "%s,", poFeature->GetFieldAsString(iField) );
            str.append( poFeature->GetFieldAsString(iField ) );
            break;
        default:
            // printf( "%s,", poFeature->GetFieldAsString(iField) );
            str.append( poFeature->GetFieldAsString(iField) );
            break;
    }
    return str;
}

/** Open shape file of node */
void PLANNING::OpenNodeSHP(){

	OGRRegisterAll();
    GDALDataset *poDS = static_cast<GDALDataset*>( GDALOpenEx( node_shp.c_str(), GDAL_OF_VECTOR, NULL, NULL, NULL ));
    if( poDS == NULL ){
        printf( "Open failed.\n" );
        exit( 1 );}

    OGRLayer  *poLayer = poDS->GetLayerByName( layer_node.c_str() );  //"C1_NODE"
    OGRFeatureDefn *poFDefn = poLayer->GetLayerDefn();
    poLayer->ResetReading();
    OGRFeature *poFeature;
    while( (poFeature = poLayer->GetNextFeature()) != NULL ) {
    	Node node;
        for( int iField = 0; iField < poFDefn->GetFieldCount(); iField++ )
        {
            OGRFieldDefn *poFieldDefn = poFDefn->GetFieldDefn( iField );
            string str = "";
            str = ParsingToString( poFieldDefn, poFeature, iField);
            unsigned long comma;
            string str_temp;
            if ( iField == shp_node_id ){
                node.id = str;
                // cout << "Node ID : " << node.id << endl;
            }
            else if ( iField == shp_node_next_link ){
                str_temp = str;
                while(str.find(",") != string::npos){
                    comma = str.find(",");
                    str_temp = str.substr(0, comma);
                    node.NLIDS.push_back(str_temp);
                    str = str.substr(comma+1);
                }
                node.NLIDS.push_back(str);
                // cout << "NEXT LID : " << str << endl;
            }
            else if ( iField == shp_node_prev_link){
                str_temp = str;
                while(str.find(",") != string::npos){
                    comma = str.find(",");
                    str_temp = str.substr(0, comma);
                    node.PLIDS.push_back(str_temp);
                    str = str.substr(comma+1);
                }
                node.PLIDS.push_back(str);
                // cout << "PREV LID : " << str << endl;
            }
        }
        
        OGRGeometry *poGeometry = poFeature->GetGeometryRef();
        if( poGeometry != NULL && wkbFlatten(poGeometry->getGeometryType()) == wkbPoint ){
            OGRPoint *poPoint = (OGRPoint *) poGeometry;
            node.geometry.x = poPoint->getX();
            node.geometry.y = poPoint->getY();

            geometry_msgs::Point p;
            p.x = node.geometry.x - OffsetMapX;
            p.y = node.geometry.y - OffsetMapY;
            MapPoints.points.push_back(p);
            // printf( "%.3f,%3.f\n", poPoint->getX(), poPoint->getY() );
        }
        else{
            printf( "NODE: no point geometry\n" );}
        
        OGRFeature::DestroyFeature( poFeature );
		nodes.insert(make_pair(node.id, node));
    }    
    GDALClose( poDS );
    
    InitializeRvizPoints();

    if(is_node_on)
   	    MapPointsPub.publish(MapPoints);
   	ROS_INFO("Received Nodes : %d", nodes.size());
}

void PLANNING::InitializeRvizPoints(){
    MapPoints.header.frame_id = "base_link";
    MapPoints.header.stamp = ros::Time::now();
    MapPoints.action = visualization_msgs::Marker::ADD;
    MapPoints.pose.orientation.w = 1.0;
    MapPoints.id = 1000;
    MapPoints.type = visualization_msgs::Marker::POINTS;
    MapPoints.scale.x = 1.5;
    MapPoints.scale.y = 1.0;
    MapPoints.color.r = 1.0;
    MapPoints.color.g = 1.0;
    MapPoints.color.b = 0.0;
    MapPoints.color.a = 1.0;        
}

/** Open shape file of link */
void PLANNING::OpenLinkSHP(){

	OGRRegisterAll();
    vector<geometry_msgs::Point> LinkGeoVector;
    GDALDataset *poDS = static_cast<GDALDataset*>( GDALOpenEx( link_shp.c_str(), GDAL_OF_VECTOR, NULL, NULL, NULL ));
    if( poDS == NULL ){
        printf( "Open failed.\n" );
        exit( 1 ); }

    OGRLayer  *poLayer = poDS->GetLayerByName( layer_link.c_str() ); //A3_LINK //"A3_LINK_Modified_V2"
    OGRFeatureDefn *poFDefn = poLayer->GetLayerDefn();
    poLayer->ResetReading();
    OGRFeature *poFeature;

    while( (poFeature = poLayer->GetNextFeature()) != NULL ){   
    	Link link;
        for( int iField = 0; iField < poFDefn->GetFieldCount(); iField++ ){
            OGRFieldDefn *poFieldDefn = poFDefn->GetFieldDefn( iField );
            string str = "";
            str = ParsingToString( poFieldDefn, poFeature, iField);
            unsigned long comma;
            string str_temp;
            if ( iField == shp_link_id){
                link.id = str;
                // cout << endl << "LINK ID : " << link.id << endl;               
            }
            else if( iField == shp_link_from_node ){
                link.from_node = str;
                // cout << "FROM NODE : " << link.from_node << endl;    
            }
            else if ( iField == shp_link_to_node ){
                link.to_node = str;
                // cout << "To NODE : " << link.to_node << endl;    
            }
            else if ( iField == shp_link_length ){
                link.length = atof( str.c_str() );
                // cout << "LEN : " << link.length << endl; 
            }
            else if ( iField == shp_link_speed ){
                link.speed = atoi( str.c_str() );
                // cout << "SPEED : " << link.speed << endl;    
            }
            else if ( iField == shp_link_left_link ){
                link.LLID.push_back( str );
                // cout<< "L LINK : " << str << endl;
            }
            else if ( iField == shp_link_right_link ){
                link.RLID.push_back( str );
                // cout<< "R LINK : " << str << endl;
            }
            else if ( iField == shp_link_next_link ){
                str_temp = str;
                while(str.find(",") != string::npos){
                comma = str.find(",");
                str_temp = str.substr(0, comma);
                link.NLIDS.push_back(str_temp);
                str = str.substr(comma+1);
                }
                link.NLIDS.push_back(str);
                // for(int i =0; i<link.NLIDS.size(); i++)
                // cout<< "NEXT LINK : " << link.NLIDS[i] << endl;
            }
        }

		char *pszWKT = NULL;
		string geometry_str;
        vector<geometry_msgs::Point> link_array;
        OGRGeometry *poGeometry = poFeature->GetGeometryRef();
        if( poGeometry != NULL && wkbFlatten(poGeometry->getGeometryType()) == wkbLineString ) {
           	poGeometry->exportToWkt(&pszWKT);
            geometry_str = pszWKT;
           	//printf("%s\n", pszWKT);
           	CPLFree(pszWKT);
        }
        else {
            printf( "LINK : no point geometry\n" );}
        
        link_array = ParsingLinkGeometry(geometry_str);
        for(int i=0; i<link_array.size(); i++){
            link.geometry.push_back(link_array[i]);
        }
        
		OGRFeature::DestroyFeature( poFeature );
		links.insert(make_pair(link.id, link));
    }

    GDALClose( poDS );
    InitializeRvizLinkArray(LinkGeoVector);

    if(is_link_on)
        LinkArrayPub.publish(LinkArray);
   	ROS_INFO("Received Links : %d", links.size());
}

vector<geometry_msgs::Point> PLANNING::ParsingLinkGeometry(string geometry_str){

    string str;
    unsigned long comma;
    unsigned long space;

    geometry_msgs::Point point;
    vector<geometry_msgs::Point> point_array;
    
    comma = geometry_str.find("(");
    geometry_str = geometry_str.substr(comma+1);
    
    while(geometry_str.find(",") != string::npos){
        comma = geometry_str.find(",");
        str = geometry_str.substr(0,comma);
        space = str.find(" ");
        point.x = atof(str.substr(0,space).c_str());
        str = str.substr(space+1);
        space = str.find(" ");
        point.y = atof(str.substr(0,space).c_str());
        point_array.push_back(point);
        geometry_str = geometry_str.substr(comma+1);
    }        

    space = geometry_str.find(" ");
    point.x = atof(geometry_str.substr(0,space).c_str());
    geometry_str = geometry_str.substr(space+1);
    space = geometry_str.find(" ");
    point.y = atof(geometry_str.substr(0,space).c_str());
    point_array.push_back(point);

    return point_array;
}

void PLANNING::InitializeRvizLinkArray(vector<geometry_msgs::Point> LinkGeoVector){
    int i = 0;

    LinkArray.markers.resize(links.size());

    for (auto it=links.begin(); it!=links.end(); it++){
        LinkArray.markers[i].header.frame_id = "base_link";
        LinkArray.markers[i].header.stamp = ros::Time::now();
        LinkArray.markers[i].action = visualization_msgs::Marker::ADD;
        LinkArray.markers[i].pose.orientation.w = 1.0;
        LinkArray.markers[i].id = i;
        LinkArray.markers[i].type = visualization_msgs::Marker::LINE_STRIP;
        LinkArray.markers[i].scale.x = 0.3;
        LinkArray.markers[i].color.r = 0.0;
        LinkArray.markers[i].color.g = 1.0;
        LinkArray.markers[i].color.b = 1.0;
        LinkArray.markers[i].color.a = 1.0; 

        LinkArray.markers[i].points.resize(it->second.geometry.size());
        LinkGeoVector.resize(it->second.geometry.size());

        for(int k= 0; k < it->second.geometry.size(); k++){
            LinkGeoVector[k].x = it->second.geometry[k].x - OffsetMapX;
            LinkGeoVector[k].y = it->second.geometry[k].y - OffsetMapY;
            LinkArray.markers[i].points[k] = LinkGeoVector[k];
        }
        LinkGeoVector.clear();
        i++;
    }
}

void PLANNING::GenerateGlobalPath(){

    ROS_INFO("Generating Global Path");

	Node current_node;
	Node goal_node;
	Link current_link;
	Cost current_cost;

    bool is_complete_path = false;

    current_cost = InitializeCost();

    closed_list.clear();
    open_list.clear();
	trajectory_points.clear();
    
    closed_list.push_back(current_cost);
    current_node = nodes.at( start_node_id );
    goal_node = nodes.at( goal_node_id );

    // cout << "[START NODE] " << endl << current_node << endl;
    // cout << "[GOAL NODE]" << endl << goal_node << endl;

    while( !is_complete_path ){
    	if( current_node.NLIDS[0] != "" ){
    		for( int i = 0; i < current_node.NLIDS.size(); i ++ ){
    			current_link = links.at( current_node.NLIDS[i] );
				Cost temp_cost = CalcCost( current_node, current_link, goal_node );

                UpdataOpenList(temp_cost);

				if( current_link.RLID[0] != "" ){
					for ( int k = 0; k < current_link.RLID.size(); k ++ ){
						// cout << "NEXT RIGHT LINK : " << current_link.RLID[k] << endl;
						Link right_link = links.at( current_link.RLID[k] );
						Cost temp_cost = CalcCost(current_node, current_link, right_link, goal_node);
                        UpdataOpenList(temp_cost);
					}
				}

				if( current_link.LLID[0] != "" ){
					for (int k = 0; k < current_link.LLID.size(); k ++ ){
						// cout << "NEXT LEFT LINK : " << current_link.LLID[k] << endl;
						Link left_link = links.at( current_link.LLID[k] );
						Cost temp_cost = CalcCost(current_node, current_link, left_link, goal_node);
                        UpdataOpenList(temp_cost);

					}
				}
    		}

    	}
    	else  {
			// cout << endl << "<---- Current node does not have any neighbors!!!! ---->" << endl;  // cout << "current node id : " << current_node.id << endl << endl;
		}

		// cout << "<Closed list>" << endl;
		// for( int k = 0; k < closed_list.size(); k ++ )
		// 	printf( "%s ", closed_list[k].node.c_str() );

		// cout<< endl << "<Open list>" << endl;
		// for(int k = 0; k < open_list.size(); k ++ )
		// 	printf( "%s ", open_list[k].node.c_str() );
		// cout<< "----------------------------------------" << endl << endl;

		float min_score = 999999;
		unsigned int path_candidate = 0;	

		for( int i = 0; i < open_list.size(); i ++ ){
			if( open_list[i].f_score < min_score ){
				min_score = open_list[i].f_score;
				// cout << "min score :  " << min_score << " id : " << open_list[i].node << endl;
				path_candidate = i;
			}
			// cout << i <<" : " <<  "min score :  " << min_score << " id : " << open_list[path_candidate].node << endl;
		}
        // cout << "min score :  " << min_score << " id : " << open_list[path_candidate].node << endl;

		closed_list.push_back( open_list[path_candidate] );
		open_list.erase( open_list.begin() + path_candidate );

		current_node = nodes.at( closed_list.back().node );

		if( closed_list.back().node == goal_node.id )
		    is_complete_path = true;
    }

    GenerateWayPoint( closed_list );
}

void PLANNING::UpdataOpenList(Cost temp_cost){

    bool is_new_open_list = false;

    for( int j = 0; j < closed_list.size(); j ++ ){
        if(temp_cost.node == closed_list[j].node && temp_cost.parent_node == closed_list[j].parent_node){
            is_new_open_list = false;
            // cout << "This node is already in the closed list!!! -> " << temp_cost.node << " & " << closed_list[j].node << " " << temp_cost.parent_node <<" & " << closed_list[j].parent_node <<endl << endl;
            break;  
        }
        else
            is_new_open_list = true;
    }

    if( is_new_open_list ){
        open_list.push_back(temp_cost);

        for( int j = 0; j < open_list.size() - 1; j ++ ){
            if(temp_cost.node == open_list[j].node && temp_cost.parent_node == open_list[j].parent_node ){
                // cout << endl << "There is same node in the open list!" << endl;
                if( temp_cost.g_score < open_list[j].g_score ){
                open_list[j].g_score = temp_cost.g_score;
                open_list[j].f_score = temp_cost.f_score;
                open_list[j].parent_node = temp_cost.parent_node;
                open_list[j].link = temp_cost.link;
                }
                open_list.pop_back();
            }
        }
    }
}

void PLANNING::GenerateWayPoint(vector<Cost> closed_list){
    
    trajectory_node.clear();
    trajectory_link.clear();
    string parent_id;

    for( int i=closed_list.size()-1; i > 0; i-- ){
        if(i == closed_list.size()-1){
            trajectory_node.push_back(closed_list[i].node);
            parent_id = closed_list[i].parent_node;
            trajectory_link.push_back(closed_list[i].link);
            // cout << closed_list[i].node_id << "  " << closed_list[i].parent_node_id <<endl;
        }
        else{
            if(parent_id == closed_list[i].node){
                trajectory_node.push_back(closed_list[i].node);
                parent_id = closed_list[i].parent_node;
                trajectory_link.push_back(closed_list[i].link);
            }
        }
    }

    trajectory_node.push_back(parent_id);

    reverse(trajectory_node.begin(), trajectory_node.end());
    reverse(trajectory_link.begin(), trajectory_link.end());

    // cout << "[Global Path Node]: " << endl;
    // for(int i=0; i<trajectory_node.size(); i++) cout<< trajectory_node[i] << endl; 

    // cout << "[Global Path Link]: " << endl;
    // for(int i=0; i<trajectory_link.size(); i++) cout<< trajectory_link[i] << endl;

    Node waypoint;
    Link waypoint_link;
    Link waypoint_near_link;
    
    geometry_msgs::Point temp; 

    for(int i=0; i<trajectory_node.size()-1 ; i++){
        waypoint = nodes.at(trajectory_node[i]);
        waypoint_link = links.at(trajectory_link[i]);

        for(int j=0; j<waypoint.NLIDS.size(); j++){
            if(waypoint.NLIDS[j] == trajectory_link[i]){
                is_lane_changed = false;                
                break;
            }
            else{
                is_lane_changed = true;                

                if(waypoint.NLIDS[j] == waypoint_link.LLID[0]){
                    waypoint_near_link = links.at(waypoint_link.LLID[0]);
                }
                else if(waypoint.NLIDS[j] == waypoint_link.RLID[0]){
                    waypoint_near_link = links.at(waypoint_link.RLID[0]);
                }
            }
        }
        if(i==0){
            GenerateStartPoint(is_lane_changed);
        }

        if (i < trajectory_node.size()-2 && i > 0 ){
            if(is_lane_changed) {
                vector<geometry_msgs::Point> curve_points = ChangeLane(waypoint_near_link, waypoint_link);
                // vector<geometry_msgs::Point> curve_points = GenerateCurvePoint(waypoint_near_link, waypoint_link);
                for (int j=0; j<curve_points.size(); j++){
                    temp.x = curve_points[j].x - OffsetMapX;
                    temp.y = curve_points[j].y - OffsetMapY;
                    trajectory_points.push_back(temp);
                }
            }
            else{      
                for(int j=0; j<waypoint_link.geometry.size(); j++){
                    temp.x = waypoint_link.geometry[j].x - OffsetMapX;
                    temp.y = waypoint_link.geometry[j].y - OffsetMapY;   
                    trajectory_points.push_back(temp);
                }
            }
        }
        // cout << "is lane chanege? " << is_lane_changed << " node: " << trajectory_node[i] << endl;
    }
}

void PLANNING::DrawingPath(){
    PathArray.header.frame_id = "base_link";
    PathArray.header.stamp = ros::Time::now();
    PathArray.action = visualization_msgs::Marker::ADD;
    PathArray.pose.orientation.w = 1.0;
    PathArray.id = 1;
    PathArray.type = visualization_msgs::Marker::LINE_STRIP;
    PathArray.scale.x = 0.8;
    PathArray.color.g = 1.0;
    PathArray.color.b = 0.5;
    PathArray.color.a = 1.0;

    PathArray.points.clear();
    for(int i=0; i<trajectory_points.size(); i++)   
        PathArray.points.push_back(trajectory_points[i]);

    if(is_path_on){
        PathArrayPub.publish(PathArray);
        // GlobalPathPub.publish(trajectory_points);
    }
}

vector<geometry_msgs::Point> PLANNING::GenerateCurvePoint(Link prev_link, Link waypoint_link){
    geometry_msgs::Point P1, P2, P3, P4;
    geometry_msgs::Point temp;
    geometry_msgs::Point start_point;
    double refer_length = prev_link.length / 2;
    int w = 0;
    bool is_P1 = false;
    int idx_p1 = 0;
    double dist=0;

    for(int i=1; i<prev_link.geometry.size(); i++){

        dist += GetDistance(prev_link.geometry[i].x, prev_link.geometry[i].y, prev_link.geometry[i-1].x, prev_link.geometry[i-1].y);
        if(prev_link.length > 50){
            if (!is_P1){
                if ( dist > (prev_link.length -50)/2 ){
                    idx_p1 = i;
                    is_P1 = true;
                }
            }
        }
        if(dist > refer_length){
            w = i;
            break;
        }
    
    }

    P1 = prev_link.geometry[idx_p1];
    P2 = prev_link.geometry[w];
    P3 = waypoint_link.geometry[waypoint_link.geometry.size() - w + 1];
    P4 = waypoint_link.geometry[waypoint_link.geometry.size()-1 - idx_p1];

    vector<geometry_msgs::Point> curve_points;
    vector<geometry_msgs::Point> bezier_points;
    geometry_msgs::Point bezier;

    if(is_P1){
        for(int i=0; i<idx_p1; i++){
            curve_points.push_back(prev_link.geometry[i]);
        }
    }

    double new_points_size = 20.0;
    for(int t=0; t < new_points_size; t++){
        double s = ((double) t)/new_points_size;
        bezier.x = P1.x * pow((1-s),3) + 3 * P2.x * s * pow(1-s, 2) + 3 * P3.x * pow(s, 2) * (1-s) + P4.x * pow(s, 3);
        bezier.y = P1.y * pow((1-s),3) + 3 * P2.y * s * pow(1-s, 2) + 3 * P3.y * pow(s, 2) * (1-s) + P4.y * pow(s, 3);

        curve_points.push_back(bezier);
    }

    if(is_P1){
        for(int i=waypoint_link.geometry.size()- idx_p1; i<waypoint_link.geometry.size(); i++){
            curve_points.push_back(waypoint_link.geometry[i]);
        }
    }
    return curve_points;
}


Cost PLANNING::InitializeCost(){
	Cost current_cost;
	current_cost.node = start_node_id;
    current_cost.g_score = 0;
    current_cost.h_score = 0;
    current_cost.f_score = 0;
    current_cost.parent_node = "NONE";
    current_cost.link = "NONE";

    return current_cost;
}


Cost PLANNING::CalcCost(Node current_node, Link current_link, Node goal_node){

	Node next_node = nodes.at(current_link.to_node);

	float g_score = current_link.length;
	float h_score = GetDistance(next_node.geometry.x, next_node.geometry.y, goal_node.geometry.x, goal_node.geometry.y);
	float f_score = g_score + h_score;

	// cout<< "parent node: [" << current_node.id << "] " << " currnet link : [" << current_link.id << "]" << " next node : [" << next_node.id << "]"<< endl; 
	// cout << "g: " << g_score << " h: " << h_score << " f: " << f_score << endl << endl;

	Cost temp_cost;
	temp_cost.node = next_node.id;
	temp_cost.g_score = g_score;
	temp_cost.h_score = h_score;
	temp_cost.f_score = f_score;
	temp_cost.parent_node = current_node.id;
	temp_cost.link = current_link.id;

	return temp_cost;
}

Cost PLANNING::CalcCost(Node current_node, Link current_link, Link lrlink, Node goal_node){

	Node next_node = nodes.at( lrlink.to_node );

	float g_score = current_link.length * weight ; //GetDistance(next_node.geometry.x, next_node.geometry.y, current_node.geometry.x, current_node.geometry.y);
	float h_score = GetDistance(next_node.geometry.x, next_node.geometry.y, goal_node.geometry.x, goal_node.geometry.y);
	float f_score = g_score + h_score;

	// cout<< "parent node: [" << current_node.id << "] " << " currnet link : [" << lrlink.id << "]" << " next node : [" << next_node.id << "]"<< endl; 
	// cout << "g: " << g_score << " h: " << h_score << " f: " << f_score << endl << endl;

	Cost temp_cost;
	temp_cost.node = next_node.id;
	temp_cost.g_score = g_score;
	temp_cost.h_score = h_score;
	temp_cost.f_score = f_score;
	temp_cost.parent_node = current_node.id;
	temp_cost.link = lrlink.id;

	return temp_cost;
}

float PLANNING::GetDistance(float pCurrent_x, float pCurrent_y, float pNext_x, float pNext_y){
	float Distance = sqrt(pow(pNext_x - pCurrent_x, 2) + pow(pNext_y - pCurrent_y, 2));
	return Distance;
}


/** This function is to use for the Vehicle with GPS */
void PLANNING::GpsCallback(const sensor_msgs::NavSatFixConstPtr& fix){

    double northing, easting;
    string zone;
    int flag=0;

    if(fix->status.status == sensor_msgs::NavSatStatus::STATUS_NO_FIX){
        ROS_INFO("No Fix.");
        return;
    }

    if(fix->header.stamp == ros::Time(0)){
        return;
    }

    LLtoUTM(fix->latitude, fix->longitude, northing, easting, zone);

    VehiclePosition.position.x = easting - OffsetMapX;
    VehiclePosition.position.y = northing - OffsetMapY;
    VehiclePosition.position.z = 0;

    is_simul_on = false;
}

void PLANNING::GpsHeadingCallback(const ublox_msgs::NavPVTConstPtr& navheading){
    NavheadingValueDeg = navheading->heading * 0.00001;
    NavheadingValueDeg = -(NavheadingValueDeg - 90);
    NavheadingValueRad = (NavheadingValueDeg * math_pi) / 180;
}

void PLANNING::VehicleClosestLink(geometry_msgs::Pose VehiclePosition){

    ROS_INFO("Finding closest start link for the vehicle");

    // double Dist, DiffTheta;
    // double yaw;
    // double dist_threshold = 3;
    // double slope, intersect, dist2link;
    // double mindist2link = 1000.0;
    // int count = 0;
    // string previd;
    // vector<pair<string,geometry_msgs::Point>> candidate_link;
    // geometry_msgs::Point GeometryPoints;

    // yaw = NavheadingValueRad;

    // while(candidate_link.size() < 2){
    //     candidate_link.clear();
    //     for (int i=0; i<GeometryPair.size(); i++){
    //         Dist = GetDistance(VehiclePosition.position.x, VehiclePosition.position.y, GeometryPair[i].second.x, GeometryPair[i].second.y);
    //         if (Dist < dist_threshold){
    //             DiffTheta = yaw - atan2(GeometryPair[i].second.y - VehiclePosition.position.y, GeometryPair[i].second.x - VehiclePosition.position.x);
    //             if(abs(DiffTheta) < math_pi/2){
    //                 candidate_link.push_back(GeometryPair[i]);
    //             }
    //         }
    //     }
    //     dist_threshold = dist_threshold + 0.5;
    // }

    // cout << "candidate : " << candidate_link.size() <<endl;


    // for(int i=0; i<candidate_link.size(); i++){
    //     if(previd != candidate_link[i].first){
    //         previd = candidate_link[i].first;
    //     }
    //     else{
    //         slope = GetSlope(candidate_link[i-1].second,candidate_link[i].second);
    //         intersect = GetIntersectY(slope, candidate_link[i].second);
    //         dist2link = abs(slope * VehiclePosition.position.x + (-1) * VehiclePosition.position.y + intersect) / sqrt(pow(slope,2) + pow(1,2));

    //         if(dist2link < mindist2link){
    //             mindist2link = dist2link;
    //             ClosestStartLinkId = candidate_link[i].first;
    //             ClosestStartLinkGeo = candidate_link[i].second;
    //             StartLinkSlope = slope;

    //             cout << "---------------------------" <<endl;
    //             cout << "ID: " << ClosestStartLinkId <<endl;
    //             cout << "Dist: " << mindist2link <<endl;
    //             cout << "Geo: " << ClosestStartLinkGeo <<endl;
    //         }
    //     }
    // }

}

void PLANNING::GlobalPathHandler(const geometry_msgs::PoseStampedPtr& NavGoalMsg){

    clock_t start =  clock();

    //* 1. Conver ros message to geometry_msgs::Pose RvizGoal
    CopyGoalPointfromRviz(NavGoalMsg);

    // LoadAllLinksGeometry();

    // //* 2. Find the closest start link
    if(!is_simul_on){
        VehicleClosestLink(VehiclePosition);
    }
    else{
        ClosestStartLink = FindClosetLink(RvizPosition);
        // ClosestStartLinkId = ClosestStartLink.first;
        // ClosestStartLinkGeo = ClosestStartLink.second;

    }
    start_node_id = links.at(ClosestStartLink.first).from_node;

    //* 3. Find the closest goal link 
    // RvizClosestEndLink();
    ClosestEndLink = FindClosetLink(RvizGoal);
    // ClosestEndLinkId = ClosestEndLink.first;
    // ClosestEndLinkGeo = ClosestEndLink.second;
    goal_node_id = links.at(ClosestEndLink.first).to_node;

    cout<< "start : " << ClosestStartLink.first << " end : " << ClosestEndLink.first << endl;

    //* 4. Generate global path 
    GenerateGlobalPath();

    //* 5. Generate global path points
    GenerateGoalPoint();

    //* 6. Draw out generated path
    DrawingPath();

    //* 7. Check operating time 
    printf("%0.5f\n", (float)(clock() - start)/CLOCKS_PER_SEC);


}

void PLANNING::CopyGoalPointfromRviz(const geometry_msgs::PoseStampedPtr& NavGoalMsg){

    RvizGoal.position.x = NavGoalMsg->pose.position.x;
    RvizGoal.position.y = NavGoalMsg->pose.position.y;
    RvizGoal.position.z = 0;

    RvizGoal.orientation.x = NavGoalMsg->pose.orientation.x;
    RvizGoal.orientation.y = NavGoalMsg->pose.orientation.y;
    RvizGoal.orientation.z = NavGoalMsg->pose.orientation.z;
    RvizGoal.orientation.w = NavGoalMsg->pose.orientation.w;

    ROS_INFO("Goal position x: %f y: %f", RvizGoal.position.x, RvizGoal.position.y);
}

void PLANNING::RvizNavStartCallback(const geometry_msgs::PoseWithCovarianceStampedPtr& NavStartMsg){

    is_simul_on = true;
    RvizPosition.position.x = NavStartMsg->pose.pose.position.x;
    RvizPosition.position.y = NavStartMsg->pose.pose.position.y;
    RvizPosition.position.z = 0;

    RvizPosition.orientation.x = NavStartMsg->pose.pose.orientation.x;
    RvizPosition.orientation.y = NavStartMsg->pose.pose.orientation.y;
    RvizPosition.orientation.z = NavStartMsg->pose.pose.orientation.z;
    RvizPosition.orientation.w = NavStartMsg->pose.pose.orientation.w;

    Test(RvizPosition);

    ROS_INFO("Start position x: %f y: %f", RvizPosition.position.x, RvizPosition.position.y);
}

void PLANNING::RvizClosestEndLink(){
    double Dist, DiffTheta;
    double siny_cosp, cosy_cosp, yaw;
    double dist_threshold = 3;
    double slope, intersect, dist2link;
    double mindist2link = 1000.0;
    int count = 0;
    int index;
    string previd = "abc";
    string minLinkId;
    vector<pair<string,geometry_msgs::Point>> candidate_link;
    geometry_msgs::Point GeometryPoints;
    geometry_msgs::Point minLinkGeometry;
    pair<string, geometry_msgs::Point> Result;

    yaw = RvizPose2yaw(RvizGoal);


    candidate_link = SetCandidateLink(RvizGoal, dist_threshold, yaw);

    Result = FindClosestIdGeo(candidate_link, RvizGoal);

    ClosestEndLinkId = Result.first;
    ClosestEndLinkGeo = Result.second;
}

double PLANNING::RvizPose2yaw(geometry_msgs::Pose pose){
    double siny_cosp = 2 * (pose.orientation.w * pose.orientation.z + pose.orientation.x * pose.orientation.y);
    double cosy_cosp = 1 - 2 * (pose.orientation.y * pose.orientation.y + pose.orientation.z * pose.orientation.z);
    double yaw = atan2(siny_cosp, cosy_cosp);

    return yaw;
}

void PLANNING::LoadAllLinksGeometry(){
    int count = 0;
    geometry_msgs::Point GeometryPoints;

    for(auto it=links.begin(); it!=links.end(); it++){
        // count = count + it->second.geometry.size();
        count = 0;
        for(auto jt=it->second.geometry.begin(); jt!=it->second.geometry.end(); jt++){
            GeometryPoints.x = jt->x - OffsetMapX;
            GeometryPoints.y = jt->y - OffsetMapY;
            GeometryPoints.z = jt->z;
            GeometryPair.push_back(pair<string, geometry_msgs::Point>(it->first, GeometryPoints));
            cout << count << endl;
            count++;
        }
    }

    ROS_INFO("Geometry points for searching: %d", GeometryPair.size());
}

pair<string, geometry_msgs::Point> PLANNING::Test(geometry_msgs::Pose CurPose){
    int count = 0;
    geometry_msgs::Point link_points, prev_link_points;
    pair<string, geometry_msgs::Point> selected_link;

    double dist, diff_theta;
    double yaw;
    double dist_threshold = 3;
    double slope, intersect, dist2link;
    double mindist2link = 1000.0;
    string minLinkId;

    yaw = RvizPose2yaw(RvizPosition);

    while(count < 1){
        count = 0;
        for(auto it=links.begin(); it!=links.end(); it++){
            // count = 0;
            for(int i = 0; i < it->second.geometry.size(); i++){
                link_points.x = it->second.geometry[i].x - OffsetMapX;
                link_points.y = it->second.geometry[i].y - OffsetMapY;
                link_points.z = it->second.geometry[i].z;

                dist = GetDistance(CurPose.position.x, CurPose.position.y, link_points.x, link_points.y);
                // cout << "dist: " << dist << " id: " << it->second.id << " i: " << i <<endl;

                if (dist < dist_threshold){
                    diff_theta = yaw - atan2(link_points.y - CurPose.position.y, link_points.x - CurPose.position.x);
                    if(abs(diff_theta) < math_pi/2){
                        
                        if(i == it->second.geometry.size()-1){
                            prev_link_points.x = it->second.geometry[i-1].x - OffsetMapX;
                            prev_link_points.y = it->second.geometry[i-1].y - OffsetMapY;
                            prev_link_points.z = it->second.geometry[i-1].z;
                            slope = GetSlope(prev_link_points, link_points);
                        }
                        else{
                            prev_link_points.x = it->second.geometry[i+1].x - OffsetMapX;
                            prev_link_points.y = it->second.geometry[i+1].y - OffsetMapY;
                            prev_link_points.z = it->second.geometry[i+1].z;
                            slope = GetSlope(link_points, prev_link_points);
                        }

                        intersect = GetIntersectY(slope, link_points);
                        dist2link = abs(slope * CurPose.position.x + (-1)*CurPose.position.y + intersect) / sqrt(pow(slope,2) + pow(1,2));
                        // cout << "intersect: " << intersect << " dist2link : " << dist2link << endl;

                        if(dist2link < mindist2link){
                            count++;
                            mindist2link = dist2link;
                            selected_link.first = it->second.id;
                            selected_link.second = link_points;

                            // cout<< "slected:  " << minLinkId << endl;
                        }

                        // cout << "i: " << i << " Distance : " << dist << " link : " << it->second.id << " slope: " << slope << " d2l: " << dist2link << endl;
                    }
                }
            }
        }

        // cout << count << endl;
        dist_threshold += 0.5;
    }

    ROS_INFO("Geometry points for searching: %d", GeometryPair.size());

    return selected_link;
}

vector<pair<string, geometry_msgs::Point>> PLANNING::SetCandidateLink(geometry_msgs::Pose CurPose, double DistThreshold, double yaw){
    vector<pair<string, geometry_msgs::Point>> CandidateLink;
    double Distance, DiffTheta;

    while(CandidateLink.size() < 2){
        CandidateLink.clear();
        for(int i=0; i < GeometryPair.size(); i++){
            Distance = GetDistance(CurPose.position.x, CurPose.position.y, GeometryPair[i].second.x, GeometryPair[i].second.y);

            if (Distance < DistThreshold){
                DiffTheta = yaw - atan2(GeometryPair[i].second.y - CurPose.position.y, GeometryPair[i].second.x - CurPose.position.x);
                cout << "i: " << i << " Distance : " << Distance << " ang: " << DiffTheta*180/math_pi << " link : " << GeometryPair[i].first << " thres:" << DistThreshold << endl;
                if(abs(DiffTheta) < math_pi/2){
                    CandidateLink.push_back(GeometryPair[i]);
                    cout << "ci: " << i << " Distance : " << Distance << " link : " << GeometryPair[i].first << " thres:" << DistThreshold << endl;
                }
            }
        }
        DistThreshold = DistThreshold + 0.5;
    }

    ROS_INFO("Candidate links: %d", CandidateLink.size());

    return CandidateLink;
}

pair<string, geometry_msgs::Point> PLANNING::FindClosestIdGeo(vector<pair<string, geometry_msgs::Point>> CandidateLink, geometry_msgs::Pose CurPose){
    string previd = CandidateLink[0].first;
    pair<string, geometry_msgs::Point> ReturnVal;
    string minLinkId;
    geometry_msgs::Point minLinkGeo;
    double mindist2link = 10000.0;

    for(int i=0; i<CandidateLink.size(); i++){
        // double temp_link =
    }


    ReturnVal.first = minLinkId;
    ReturnVal.second = minLinkGeo;

    ROS_INFO("Closest link: %s", minLinkId.c_str());

    return ReturnVal;
}

// pair<string, geometry_msgs::Point> PLANNING::FindClosestIdGeo(vector<pair<string, geometry_msgs::Point>> CandidateLink, geometry_msgs::Pose CurPose){
//     string previd = CandidateLink[0].first;
//     pair<string, geometry_msgs::Point> ReturnVal;
//     string minLinkId;
//     geometry_msgs::Point minLinkGeo;
//     double mindist2link = 10000.0;
//     for(int i=1; i<CandidateLink.size(); i++){
//         double slope = GetSlope(CandidateLink[i-1].second, CandidateLink[i].second);
//         cout << "SLOPE: " << slope << endl;
//         double intersect = GetIntersectY(slope, CurPose.position);
//         double dist2link = abs(slope * CurPose.position.x + (-1)*CurPose.position.y + intersect) / sqrt(pow(slope,2) + pow(1,2));

//         if(dist2link < mindist2link){
//             mindist2link = dist2link;
//             minLinkId = CandidateLink[i].first;
//             minLinkGeo = CandidateLink[i].second;
//         }
//     }

//     ReturnVal.first = minLinkId;
//     ReturnVal.second = minLinkGeo;

//     ROS_INFO("Closest link: %s", minLinkId.c_str());

//     return ReturnVal;
// }


// These Functions are to test in Rviz Simulation.
void PLANNING::RvizClosestStartLink(geometry_msgs::Pose RvizPosition){

    ROS_INFO("Finding closest start link in RVIZ");

    double yaw;
    double dist_threshold = 3;
    vector<pair<string,geometry_msgs::Point>> candidate_link;
    pair<string, geometry_msgs::Point> Result;
    
    yaw = RvizPose2yaw(RvizPosition);

    candidate_link = SetCandidateLink(RvizPosition, dist_threshold, yaw);

    Result = FindClosestIdGeo(candidate_link, RvizPosition);

    ClosestStartLinkId = Result.first;
    ClosestStartLinkGeo = Result.second;
}

double PLANNING::GetSlope(geometry_msgs::Point a, geometry_msgs::Point b){
    double slope;
    return slope = (b.y - a.y) / (b.x - a.x);
}

double PLANNING::GetIntersectY(double slope, geometry_msgs::Point a){
    double intersect;
    return intersect = -(slope * a.x) + a.y;
}

void PLANNING::GenerateGoalPoint(){

    ROS_INFO("Generating end points of the path");
    Link goal_link = links.at(ClosestEndLinkId);
    int min_idx = 0;
    Link to_link;

    vector<geometry_msgs::Point> generated_points;
    geometry_msgs::Point temp;

    if(is_lane_changed){
        if(goal_link.LLID[0]!=""){
            to_link = links.at(links.at(ClosestEndLinkId).LLID[0]);
        }
        else if(goal_link.RLID[0]!=""){
            to_link = links.at(links.at(ClosestEndLinkId).RLID[0]);
        }

        generated_points = GoalLinkChangeLane(to_link, goal_link);

        for(int i=0; i < generated_points.size(); i++){
            temp.x = generated_points[i].x - OffsetMapX;
            temp.y = generated_points[i].y - OffsetMapY;
            trajectory_points.push_back(temp);
        }
    }
    else{
        min_idx = SearchClosestIndex(ClosestEndLinkGeo, goal_link);
        for(int i=0; i< min_idx+1; i++){
            temp.x = goal_link.geometry[i].x - OffsetMapX;
            temp.y = goal_link.geometry[i].y - OffsetMapY;
            trajectory_points.push_back(temp);
        }
    }

}

void PLANNING::GenerateStartPoint(bool is_lane_changed){

    ROS_INFO("Generating start points of the path");
    Link start_link = links.at(ClosestStartLinkId);
    Link to_link;
    int min_idx;
    vector<geometry_msgs::Point> generated_points;
    geometry_msgs::Point temp;
    
    if(is_lane_changed){
        if (start_link.LLID[0]!=""){
            to_link = links.at(links.at(ClosestStartLinkId).LLID[0]);
        }
        else if(start_link.RLID[0]!=""){            
            to_link = links.at(links.at(ClosestStartLinkId).RLID[0]);
        }

        for(int i=0; i<to_link.geometry.size(); i++){
            temp.x = to_link.geometry[i].x - OffsetMapX;
            temp.y = to_link.geometry[i].y - OffsetMapY;
            trajectory_points.push_back(temp);
        }

    }
    else{
        for(int i = 0; i < start_link.geometry.size() ; i++){
            temp.x = start_link.geometry[i].x - OffsetMapX;
            temp.y = start_link.geometry[i].y - OffsetMapY;
            trajectory_points.push_back(temp);
        }        
    }

}


vector<geometry_msgs::Point> PLANNING::ChangeLane(Link from_link, Link to_link){

    cout << "-> Change Lane" << endl;

    double length_from_link;
    double length_to_link;
    double length_to_p1;
    double length_to_p2;
    double length_to_p3;
    double length_to_p4;

    int coef = 2;

    bool is_lane_long = false;

    Bezier bezier_param;
    geometry_msgs::Point bezier;
    geometry_msgs::Point P1, P2, P3, P4;
    vector<geometry_msgs::Point> curved_points;

    length_from_link = CalcLength(from_link, 0, from_link.geometry.size()-1);
    length_to_link = CalcLength(to_link, 0, to_link.geometry.size()-1);

    if(length_from_link > length_lane_changed || length_to_link > length_lane_changed){
        is_lane_long = true;
        length_to_p1 = (length_from_link - length_lane_changed) / 2 ;
        length_to_p2 = ((length_from_link - length_lane_changed) / 2 ) + (length_lane_changed / coef);
        length_to_p3 = ((length_to_link - length_lane_changed) / 2 ) + ((length_lane_changed * (coef-1))/ coef);
        length_to_p4 = ((length_to_link - length_lane_changed) / 2 ) + length_lane_changed;
    }
    else{
        length_to_p1 = 0;
        length_to_p2 = length_from_link / coef;
        length_to_p3 = (length_to_link * (coef-1))/ coef;
        length_to_p4 = length_to_link;
    }

    bezier_param.p1_idx = SearchIndex(from_link, 0, from_link.geometry.size()-1, length_to_p1);
    bezier_param.p2_idx = SearchIndex(from_link, 0, from_link.geometry.size()-1, length_to_p2);
    bezier_param.p3_idx = SearchIndex(to_link, 0, to_link.geometry.size()-1, length_to_p3);
    bezier_param.p4_idx = SearchIndex(to_link, 0, to_link.geometry.size()-1, length_to_p4);

    P1 = from_link.geometry[bezier_param.p1_idx];
    P2 = from_link.geometry[bezier_param.p2_idx];
    P3 = to_link.geometry[bezier_param.p3_idx];
    P4 = to_link.geometry[bezier_param.p4_idx];

    if(is_lane_long){
        for(int i=0; i<bezier_param.p1_idx+1; i++){
            curved_points.push_back(from_link.geometry[i]);
        }
    }

    double new_points_size = 20.0;
    for(int t=0; t < new_points_size; t++){
        double s = ((double) t)/new_points_size;
        bezier.x = P1.x * pow((1-s),3) + 3 * P2.x * s * pow(1-s, 2) + 3 * P3.x * pow(s, 2) * (1-s) + P4.x * pow(s, 3);
        bezier.y = P1.y * pow((1-s),3) + 3 * P2.y * s * pow(1-s, 2) + 3 * P3.y * pow(s, 2) * (1-s) + P4.y * pow(s, 3);
        curved_points.push_back(bezier);
    }

    if(is_lane_long){
        for(int i=bezier_param.p4_idx; i<to_link.geometry.size(); i++){
            curved_points.push_back(to_link.geometry[i]);
        }
    }

    return curved_points;
}

vector<geometry_msgs::Point> PLANNING::GoalLinkChangeLane(Link from_link, Link to_link){

    cout << "-> Change Lane" << endl;

    double length_from_link;  // The length of the from_link which is the previous link before changing the lane
    double length_to_link;    // The length of the to_link which is the future link after the changing the lane
    double length_to_p1;      
    double length_to_p2;
    double length_to_p3;
    double length_to_p4;

    int coef = 2;

    bool is_lane_long = false;

    Bezier bezier_param;
    geometry_msgs::Point bezier;
    geometry_msgs::Point P1, P2, P3, P4;
    vector<geometry_msgs::Point> curved_points;

    int to_link_start_idx;
    int from_link_end_idx;


    bezier_param.start_idx = 0;
    from_link_end_idx = SearchClosestIndex(ClosestEndLinkGeo, from_link);
    to_link_start_idx = 0;
    bezier_param.end_idx = SearchClosestIndex(ClosestEndLinkGeo, to_link);   

    length_from_link = CalcLength(from_link, bezier_param.start_idx, from_link_end_idx);
    length_to_link = CalcLength(to_link, to_link_start_idx, bezier_param.end_idx);

    if(length_from_link > length_lane_changed || length_to_link > length_lane_changed){
        is_lane_long = true;
        length_to_p1 = (length_from_link - length_lane_changed) ;
        length_to_p2 = ((length_from_link - length_lane_changed)) + (length_lane_changed / coef);
        length_to_p3 = ((length_to_link - length_lane_changed)) + ((length_lane_changed * (coef-1))/ coef);
        length_to_p4 = ((length_to_link - length_lane_changed)) + length_lane_changed;
    }
    else{
        length_to_p1 = 0;
        length_to_p2 = length_from_link / coef;
        length_to_p3 = (length_to_link * (coef-1))/ coef;
        length_to_p4 = length_to_link;
    }

    bezier_param.p1_idx = SearchIndex(from_link, bezier_param.start_idx, from_link_end_idx, length_to_p1);
    bezier_param.p2_idx = SearchIndex(from_link, bezier_param.start_idx, from_link_end_idx, length_to_p2);
    bezier_param.p3_idx = SearchIndex(to_link, to_link_start_idx, bezier_param.end_idx, length_to_p3);
    bezier_param.p4_idx = SearchIndex(to_link, to_link_start_idx, bezier_param.end_idx, length_to_p4);

    P1 = from_link.geometry[bezier_param.p1_idx];
    P2 = from_link.geometry[bezier_param.p2_idx];
    P3 = to_link.geometry[bezier_param.p3_idx];
    P4 = to_link.geometry[bezier_param.p4_idx];

    if(is_lane_long){
        for(int i=0; i<bezier_param.p1_idx + 1; i++){
            curved_points.push_back(from_link.geometry[i]);
        }
    }

    double new_points_size = 20.0;
    for(int t=0; t < new_points_size; t++){
        double s = ((double) t)/new_points_size;
        bezier.x = P1.x * pow((1-s),3) + 3 * P2.x * s * pow(1-s, 2) + 3 * P3.x * pow(s, 2) * (1-s) + P4.x * pow(s, 3);
        bezier.y = P1.y * pow((1-s),3) + 3 * P2.y * s * pow(1-s, 2) + 3 * P3.y * pow(s, 2) * (1-s) + P4.y * pow(s, 3);
        curved_points.push_back(bezier);
    }

    geometry_msgs::Point temp;
    temp.x = ClosestEndLinkGeo.x + OffsetMapX;
    temp.y = ClosestEndLinkGeo.y + OffsetMapY;
    curved_points.push_back(temp);
    
    return curved_points;
}

int PLANNING::SearchClosestIndex(geometry_msgs::Point point, Link link){
    double min_dist = 9999;
    int min_idx = 0;
    double dist;

    for(int i=0; i<link.geometry.size()-1; i++){
        dist = GetDistance(point.x, point.y, link.geometry[i].x - OffsetMapX, link.geometry[i].y - OffsetMapY);
        // cout<< "dist : " << dist << " min: " << min_dist << " idx : " << min_idx << endl;
        if(dist < min_dist){
            min_dist = dist;
            min_idx = i;            
        }
    }
    return min_idx;
}

double PLANNING::CalcLength(Link link, int from_idx, int to_idx){

    double length = 0;
    if (to_idx > from_idx){
        for(int i = from_idx; i < to_idx; i++){
            length += GetDistance(link.geometry[i].x, link.geometry[i].y, link.geometry[i+1].x, link.geometry[i+1].y);
        }    
    }
    else if(from_idx > to_idx){
        for(int i = from_idx; i > to_idx; i--){
            length += GetDistance(link.geometry[i].x, link.geometry[i].y, link.geometry[i-1].x, link.geometry[i-1].y);
        }    
    }
    else{
        length = 0;
    }

    return length;
    
}


int PLANNING::SearchIndex(Link link, int from_idx, int to_idx, double refer_length){

    double length = 0;
    int index = 0;

    if (to_idx > from_idx){
        for(int i = from_idx; i < to_idx; i++){
            length += GetDistance(link.geometry[i].x, link.geometry[i].y, link.geometry[i+1].x, link.geometry[i+1].y);
            if(length >= refer_length){
                index = i;
                break;
            }
        }    
    }
    else if(from_idx > to_idx){
        for(int i = from_idx; i > to_idx; i--){
            length += GetDistance(link.geometry[i].x, link.geometry[i].y, link.geometry[i-1].x, link.geometry[i-1].y);
            if(length >= refer_length){
                index = i;
                break;
            }
        }    
    }

    return index;
}