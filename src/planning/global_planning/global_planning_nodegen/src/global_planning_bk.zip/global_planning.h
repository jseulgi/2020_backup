/**
  @ class 	PLANNING
  @ date	2020/01
  @ author 	Seulgi Jeon, CKS
  @ description	: Generate node which contains global path data
*/

#ifndef GLOBAL_PLANNING_H
#define GLOBAL_PLANNING_H

#include <ros/ros.h>
#include <vector>
#include <map>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cmath>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <geometry_msgs/PoseStamped.h>
#include <sensor_msgs/NavSatStatus.h>
#include <sensor_msgs/NavSatFix.h>
#include "path_msgs/Node.h"
#include "path_msgs/Link.h"
#include "path_msgs/Cost.h"
#include "path_msgs/Bezier.h"
#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>
#include <sensor_msgs/NavSatStatus.h>
#include <sensor_msgs/NavSatFix.h>
#include <sensor_msgs/Imu.h>
#include "conversions.h"
#include "nav_msgs/Odometry.h"
#include "ogrsf_frmts.h"
#include "ublox_msgs/NavPVT.h"
#include <time.h>
#include <ctime>
#include <cstdio>

#define math_pi 3.1415926535897931

using namespace std;
using namespace gps_common;
using namespace path_msgs;

class PLANNING
{
public:
	PLANNING();
	~PLANNING();

private:
	ros::NodeHandle nh;/**< ros node handler */
	ros::Publisher OdometryPub;/**< odometry publisher */
	ros::Publisher MapLineStripPub;/**< map line strip publisher for rivz*/
	ros::Publisher MapPointsPub;
	ros::Publisher LinkArrayPub;
	ros::Publisher LineArrayPub;
	ros::Publisher StopArrayPub;
	ros::Publisher PathArrayPub;
	ros::Publisher GlobalPathPub;
	ros::Publisher OffsetMapPub;

	double rot_cov;
	string frame_id, child_frame_id;
	double OffsetMapX;
	double OffsetMapY;
	geometry_msgs::Point OffsetMap;

	geometry_msgs::Point StopPoint;
	visualization_msgs::MarkerArray LineArray;
	visualization_msgs::MarkerArray LinkArray;
	visualization_msgs::MarkerArray StopArray;
	visualization_msgs::Marker MapLineStrip;
	visualization_msgs::Marker MapPoints;
	visualization_msgs::Marker PathArray;

	void SetParams();
	void ReadShapeFile(string file_name, string layer_name);
	void InitializeRvizPoints();
	void InitializeRvizLaneArray(int len);
	void InitializeRvizLinkArray(vector<geometry_msgs::Point> LinkGeoVector);
	void ParsingLaneGeometry(vector<string> StringLaneVector);
	vector<geometry_msgs::Point> ParsingLinkGeometry(string geometry_str);
	string ParsingToString (OGRFieldDefn *poFieldDefn, OGRFeature *poFeature, int iField);
	void OpenNodeSHP();
	void OpenLinkSHP();
	void OpenLaneSHP();
    void GlobalPathHandler(const geometry_msgs::PoseStampedPtr& NavGoalMsg);
    void CopyGoalPointfromRviz(const geometry_msgs::PoseStampedPtr& NavGoalMsg);
	void GenerateGlobalPath();
	void UpdataOpenList(Cost temp_cost);
	void DrawingPath();
	void GenerateWayPoint(vector<Cost> closed_list);
	vector<geometry_msgs::Point> GenerateCurvePoint(Link prev_link, Link waypoint_link);
	Cost InitializeCost();
	Cost CalcCost(Node current_node, Link current_link, Node goal_node);
	Cost CalcCost(Node current_node, Link current_link, Link lrlink, Node goal_node);
	float GetDistance(float pCurrent_x, float pCurrent_y, float pNext_x, float pNext_y);

	vector<geometry_msgs::Point> ChangeLane(Link from_link, Link to_link);
	vector<geometry_msgs::Point> GoalLinkChangeLane(Link from_link, Link to_link);

	double CalcLength(Link link, int from_idx, int to_idx);
	int SearchIndex(Link link, int from_idx, int to_idx, double refer_length);
	int SearchClosestIndex(geometry_msgs::Point point, Link link);

	// CK //
	void RvizNavStartCallback(const geometry_msgs::PoseWithCovarianceStampedPtr& NavStartMsg);
	void RvizNavGoalCallback(const geometry_msgs::PoseStamped &NavGoal);
	void RvizClosestStartLink(geometry_msgs::Pose RvizPosition);
	void RvizClosestEndLink();
	void VehicleClosestLink(geometry_msgs::Pose VehiclePosition);
	void GpsCallback(const sensor_msgs::NavSatFixConstPtr& fix);
	void GpsHeadingCallback(const ublox_msgs::NavPVTConstPtr& navheading);
	double GetSlope(geometry_msgs::Point a, geometry_msgs::Point b);
	double GetIntersectY(double slope, geometry_msgs::Point a);
	double RvizPose2yaw(geometry_msgs::Pose pose);
	void LoadAllLinksGeometry();
	vector<pair<string, geometry_msgs::Point>> SetCandidateLink(geometry_msgs::Pose CurPose, double DistThreshold, double yaw);
	pair<string, geometry_msgs::Point> FindClosestIdGeo(vector<pair<string, geometry_msgs::Point>> CandidateLink, geometry_msgs::Pose CurPose);

	void GenerateGoalPoint();
	void GenerateStartPoint(bool is_lane_changed);

	pair<string, geometry_msgs::Point> FindClosetLink(geometry_msgs::Pose CurPose);
	pair<string, geometry_msgs::Point> ClosestStartLink, ClosestEndLink;


	/**< Parameters of NodeGen set from the rosparam */
	bool is_link_on;
	bool is_lane_on;
	bool is_node_on;
	bool is_path_on;

	bool is_simul_on;

	string lane_shp;
	string link_shp;
	string node_shp;
	// string stop_shp;

	string start_node_id;
	string goal_node_id; 

	string layer_lane;
	string layer_link;
	string layer_node;
 	
	int shp_link_id;
    int shp_link_from_node;
    int shp_link_to_node;
   	int shp_link_length;
    int shp_link_speed;
    int shp_link_left_link;
    int shp_link_right_link;
    int shp_link_next_link;

    int shp_node_id;
    int shp_node_next_link;
    int shp_node_prev_link;

    double weight;
    /*---------------------------------------------------**/

	map<string, Node> nodes;
	map<string, Link> links;

	vector<string> trajectory_link;
	vector<string> trajectory_node;
	vector<Cost> open_list;
	vector<Cost> closed_list;

	bool is_lane_changed;
	double length_lane_changed;

	vector<geometry_msgs::Point> trajectory_points;
	// CK // 

	vector<pair<string, geometry_msgs::Point>> GeometryPair;

	double NavheadingValueRad;
	double NavheadingValueDeg;
	double StartLinkSlope;
	double EndLinkSlope;
	// string ClosestStartLinkId;
	// string ClosestEndLinkId;
	string VehicleClosestLinkId;
	// geometry_msgs::Point ClosestStartLinkGeo;
	// geometry_msgs::Point ClosestEndLinkGeo;
	geometry_msgs::Point VehicleClosestGeo;
	geometry_msgs::Pose RvizPosition;
	geometry_msgs::Pose RvizGoal;
	geometry_msgs::Point OffsetGps;
	geometry_msgs::Pose VehiclePosition;
};

#endif 