#include "global_planning.h"


PLANNING::PLANNING()
{
    SetParams();
    if(is_lane_on)
        LineArrayPub = nh.advertise<visualization_msgs::MarkerArray>("line_array",1);
    if(is_node_on)
        MapPointsPub = nh.advertise<visualization_msgs::Marker>("nodes",1);
    if(is_link_on)
        LinkArrayPub = nh.advertise<visualization_msgs::MarkerArray>("link_array",1);
    if(is_path_on)
        PathArrayPub = nh.advertise<visualization_msgs::Marker>("/globalPath",1);
	
    // < Subscriber >
    static ros::Subscriber GpsPositionSub = nh.subscribe("/gps/fix",1,&PLANNING::GpsCallback,this);
    static ros::Subscriber GpsHeadingSub = nh.subscribe("/gps/navpvt",1,&PLANNING::GpsHeadingCallback,this);
    static ros::Subscriber RvizPositionSub = nh.subscribe("/initialpose",1,&PLANNING::RvizPoseEstimateCallback,this);
    static ros::Subscriber RvizEndSub = nh.subscribe("/move_base_simple/goal",1,&PLANNING::RvizNavGoalCallback,this);

    int i = 0;
    while(i < 10){
       OpenLaneSHP();
       OpenLinkSHP();
       OpenNodeSHP();
	   i++;
    }
}

PLANNING::~PLANNING(){
}

void PLANNING::SetParams()
{
    nh = ros::NodeHandle("~");
    nh.param("/rviz_on/is_link_on", is_link_on, true);
    nh.param("/rviz_on/is_node_on", is_node_on, true);
    nh.param("/rviz_on/is_lane_on", is_lane_on, true);
    nh.param("/rviz_on/is_path_on", is_path_on, true);

    nh.param<std::string>("/shp/lane", lane_shp, "/home/jsg/AutoCar/Material/[0] HdMap/HD_Map/KIAPI Vector HD Map/A1_LANE/A1_LANE.shp");
    nh.param<std::string>("/shp/link", link_shp, "/home/jsg/AutoCar/Material/[0] HdMap/HD_Map/KIAPI Vector HD Map/A3_LINK/A3_LINK.shp");
    nh.param<std::string>("/shp/node", node_shp, "/home/jsg/AutoCar/Material/[0] HdMap/HD_Map/KIAPI Vector HD Map/C1_NODE/C1_NODE.shp");

    nh.param<std::string>("/layer/lane", layer_lane, "A1_LANE");
    nh.param<std::string>("/layer/link", layer_link, "A3_LINK");
    nh.param<std::string>("/layer/node", layer_node, "C1_NODE");

    nh.param("/link/id", shp_link_id, 0);
    nh.param("/link/from_node", shp_link_from_node, 1);
    nh.param("/link/to_node", shp_link_to_node, 2);
    nh.param("/link/length", shp_link_length, 3);
    nh.param("/link/speed", shp_link_speed, 6);
    nh.param("/link/left_link", shp_link_left_link, 16);
    nh.param("/link/right_link", shp_link_right_link, 17);
    nh.param("/link/next_link", shp_link_next_link, 18);

    nh.param("/node/id", shp_node_id, 0);
    nh.param("/node/next_link", shp_node_next_link, 8);
    nh.param("/node/prev_link", shp_node_prev_link, 9);

    nh.param<double>("/lane_change/weight", weight, 4);

    ROS_INFO("LANE_SHAPEFILE : \n%s\n", lane_shp.c_str());
    ROS_INFO("LINK_SHAPEFILE : \n%s\n", link_shp.c_str());
    ROS_INFO("NODE_SHAPEFILE : \n%s\n", node_shp.c_str());
    ROS_INFO("Layer: \n %s  %s  %s  \n", layer_lane.c_str(), layer_link.c_str(), layer_node.c_str());
}

void PLANNING::OpenLaneSHP(){

	OGRRegisterAll();
	vector<string> StringLaneVector;
	vector<geometry_msgs::Point> LaneGeoVector;
    GDALDataset *poDS = static_cast<GDALDataset*>( GDALOpenEx( lane_shp.c_str(), GDAL_OF_VECTOR, NULL, NULL, NULL ));

    if( poDS == NULL ){
        printf( "Open failed.\n" );
        exit( 1 );}

    OGRLayer  *poLayer = poDS->GetLayerByName( layer_lane.c_str() );
    OGRFeatureDefn *poFDefn = poLayer->GetLayerDefn();
    poLayer->ResetReading();
    OGRFeature *poFeature;
    while( (poFeature = poLayer->GetNextFeature()) != NULL ){
		char *pszWKT = NULL;
        OGRGeometry *poGeometry = poFeature->GetGeometryRef();
        if( poGeometry != NULL && wkbFlatten(poGeometry->getGeometryType()) == wkbLineString ){
           	poGeometry->exportToWkt(&pszWKT);
           	StringLaneVector.push_back(pszWKT);
           	// printf("%s\n", pszWKT);
           	CPLFree(pszWKT);
        }
        else{
            printf( "LANE : no point geometry\n" );}

        OGRFeature::DestroyFeature( poFeature );
    }
    GDALClose( poDS );

    InitializeRvizLaneArray(StringLaneVector.size());
    ParsingLaneGeometry(StringLaneVector, LaneGeoVector);

    if(is_lane_on)
	   LineArrayPub.publish(LineArray);
}

void PLANNING::InitializeRvizLaneArray(int len){
    LineArray.markers.resize(len);
    for(unsigned int i=0; i<len; i++){
        LineArray.markers[i].header.frame_id = "base_link";
        LineArray.markers[i].header.stamp = ros::Time::now();
        LineArray.markers[i].action = visualization_msgs::Marker::ADD;
        LineArray.markers[i].pose.orientation.w = 1.0;
        LineArray.markers[i].id = i;
        LineArray.markers[i].type = visualization_msgs::Marker::LINE_STRIP;
        LineArray.markers[i].scale.x = 0.3;
        LineArray.markers[i].color.r = 1.0;
        LineArray.markers[i].color.g = 1.0;
        LineArray.markers[i].color.b = 1.0;
        LineArray.markers[i].color.a = 1.0;     
    }   
}

void PLANNING::ParsingLaneGeometry(vector<string> StringLaneVector, vector<geometry_msgs::Point> LaneGeoVector){
    
    geometry_msgs::Point LanePoint;
    string geometry_str;
    string str;
    unsigned long comma;
    unsigned long space;
    
    comma = StringLaneVector[0].find("(");
    geometry_str = StringLaneVector[0].substr(comma+1);
    comma = geometry_str.find(" ");
    str = geometry_str.substr(0,comma);
    OffsetMapX = atof(str.c_str());
    geometry_str = geometry_str.substr(comma+1);
    comma = geometry_str.find(" ");
    str = geometry_str.substr(0,comma);
    OffsetMapY = atof(str.c_str());

    for(int i=0; i<StringLaneVector.size(); i++){
        geometry_str = StringLaneVector[i];
        comma = geometry_str.find("(");
        geometry_str = geometry_str.substr(comma+1);

        while(geometry_str.find(",") != string::npos){
            comma = geometry_str.find(",");
            str = geometry_str.substr(0,comma);
            space = str.find(" ");
            LanePoint.x = atof(str.substr(0,space).c_str());
            str = str.substr(space+1);
            space = str.find(" ");
            LanePoint.y = atof(str.substr(0,space).c_str());
            LanePoint.z = 0;
            LaneGeoVector.push_back(LanePoint);
            geometry_str = geometry_str.substr(comma+1);

        }
        space = geometry_str.find(" ");
        LanePoint.x = atof(geometry_str.substr(0,space).c_str()) ;
        geometry_str = geometry_str.substr(space+1);
        space = geometry_str.find(" ");
        LanePoint.y = atof(geometry_str.substr(0,space).c_str());
        LanePoint.z = 0;
        LaneGeoVector.push_back(LanePoint);
        LineArray.markers[i].points.resize(LaneGeoVector.size());

        for(int j = 0; j< LaneGeoVector.size(); j++){
            LaneGeoVector[j].x = LaneGeoVector[j].x - OffsetMapX;
            LaneGeoVector[j].y = LaneGeoVector[j].y - OffsetMapY;
            LineArray.markers[i].points[j] = LaneGeoVector[j];

        }
        LaneGeoVector.clear();
    }
}

string PLANNING::ParsingToString (OGRFieldDefn *poFieldDefn, OGRFeature *poFeature, int iField){

    string str = "";
    switch( poFieldDefn->GetType() )
    {
        case OFTInteger:
            // printf( "%d,", poFeature->GetFieldAsInteger( iField ) );
            str.append( to_string( poFeature->GetFieldAsInteger(iField) ) );
            break;
        case OFTInteger64:
            // printf( CPL_FRMT_GIB ",", poFeature->GetFieldAsInteger64( iField ) );
            str.append( to_string( poFeature->GetFieldAsInteger64(iField) ) );
            break;
        case OFTReal:
            // printf( "%.3f,", poFeature->GetFieldAsDouble(iField) );
            str.append( to_string( poFeature->GetFieldAsDouble(iField) ) );
            break;
        case OFTString:
            // printf( "%s,", poFeature->GetFieldAsString(iField) );
            str.append( poFeature->GetFieldAsString(iField ) );
            break;
        default:
            // printf( "%s,", poFeature->GetFieldAsString(iField) );
            str.append( poFeature->GetFieldAsString(iField) );
            break;
    }
    return str;
}

void PLANNING::OpenNodeSHP(){

	OGRRegisterAll();
    GDALDataset *poDS = static_cast<GDALDataset*>( GDALOpenEx( node_shp.c_str(), GDAL_OF_VECTOR, NULL, NULL, NULL ));
    if( poDS == NULL ){
        printf( "Open failed.\n" );
        exit( 1 );}

    OGRLayer  *poLayer = poDS->GetLayerByName( layer_node.c_str() );  //"C1_NODE"
    OGRFeatureDefn *poFDefn = poLayer->GetLayerDefn();
    poLayer->ResetReading();
    OGRFeature *poFeature;
    while( (poFeature = poLayer->GetNextFeature()) != NULL ) {
    	Node node;
        for( int iField = 0; iField < poFDefn->GetFieldCount(); iField++ )
        {
            OGRFieldDefn *poFieldDefn = poFDefn->GetFieldDefn( iField );
            string str = "";
            str = ParsingToString( poFieldDefn, poFeature, iField);
            unsigned long comma;
            string str_temp;
            if ( iField == shp_node_id ){
                node.id = str;
                // cout << "Node ID : " << node.id << endl;
            }
            else if ( iField == shp_node_next_link ){
                str_temp = str;
                while(str.find(",") != string::npos){
                    comma = str.find(",");
                    str_temp = str.substr(0, comma);
                    node.NLIDS.push_back(str_temp);
                    str = str.substr(comma+1);
                }
                node.NLIDS.push_back(str);
                // cout << "NEXT LID : " << str << endl;
            }
            else if ( iField == shp_node_prev_link){
                str_temp = str;
                while(str.find(",") != string::npos){
                    comma = str.find(",");
                    str_temp = str.substr(0, comma);
                    node.PLIDS.push_back(str_temp);
                    str = str.substr(comma+1);
                }
                node.PLIDS.push_back(str);
                // cout << "PREV LID : " << str << endl;
            }
        }
        
        OGRGeometry *poGeometry = poFeature->GetGeometryRef();
        if( poGeometry != NULL && wkbFlatten(poGeometry->getGeometryType()) == wkbPoint ){
            OGRPoint *poPoint = (OGRPoint *) poGeometry;
            node.geometry.x = poPoint->getX();
            node.geometry.y = poPoint->getY();

            geometry_msgs::Point p;
            p.x = node.geometry.x - OffsetMapX;
            p.y = node.geometry.y - OffsetMapY;
            MapPoints.points.push_back(p);
            // printf( "%.3f,%3.f\n", poPoint->getX(), poPoint->getY() );
        }
        else{
            printf( "NODE: no point geometry\n" );}
        
        OGRFeature::DestroyFeature( poFeature );
		nodes.insert(make_pair(node.id, node));
    }    
    GDALClose( poDS );
    
    InitializeRvizPoints();

    if(is_node_on)
   	    MapPointsPub.publish(MapPoints);
   	// ROS_INFO("Received Nodes : %d", nodes.size());
}

void PLANNING::InitializeRvizPoints(){
    MapPoints.header.frame_id = "base_link";
    MapPoints.header.stamp = ros::Time::now();
    MapPoints.action = visualization_msgs::Marker::ADD;
    MapPoints.pose.orientation.w = 1.0;
    MapPoints.id = 1000;
    MapPoints.type = visualization_msgs::Marker::POINTS;
    MapPoints.scale.x = 1.5;
    MapPoints.scale.y = 1.0;
    MapPoints.color.r = 1.0;
    MapPoints.color.g = 1.0;
    MapPoints.color.b = 0.0;
    MapPoints.color.a = 1.0;        
}

void PLANNING::OpenLinkSHP(){

	OGRRegisterAll();
    vector<geometry_msgs::Point> LinkGeoVector;
    GDALDataset *poDS = static_cast<GDALDataset*>( GDALOpenEx( link_shp.c_str(), GDAL_OF_VECTOR, NULL, NULL, NULL ));
    if( poDS == NULL ){
        printf( "Open failed.\n" );
        exit( 1 ); }

    OGRLayer  *poLayer = poDS->GetLayerByName( layer_link.c_str() ); //A3_LINK //"A3_LINK_Modified_V2"
    OGRFeatureDefn *poFDefn = poLayer->GetLayerDefn();
    poLayer->ResetReading();
    OGRFeature *poFeature;

    while( (poFeature = poLayer->GetNextFeature()) != NULL ){   
    	Link link;
        for( int iField = 0; iField < poFDefn->GetFieldCount(); iField++ ){
            OGRFieldDefn *poFieldDefn = poFDefn->GetFieldDefn( iField );
            string str = "";
            str = ParsingToString( poFieldDefn, poFeature, iField);
            unsigned long comma;
            string str_temp;
            if ( iField == shp_link_id){
                link.id = str;
                // cout << endl << "LINK ID : " << link.id << endl;               
            }
            else if( iField == shp_link_from_node ){
                link.from_node = str;
                // cout << "FROM NODE : " << link.from_node << endl;    
            }
            else if ( iField == shp_link_to_node ){
                link.to_node = str;
                // cout << "To NODE : " << link.to_node << endl;    
            }
            else if ( iField == shp_link_length ){
                link.length = atof( str.c_str() );
                // cout << "LEN : " << link.length << endl; 
            }
            else if ( iField == shp_link_speed ){
                link.speed = atoi( str.c_str() );
                // cout << "SPEED : " << link.speed << endl;    
            }
            else if ( iField == shp_link_left_link ){
                link.LLID.push_back( str );
                // cout<< "L LINK : " << str << endl;
            }
            else if ( iField == shp_link_right_link ){
                link.RLID.push_back( str );
                // cout<< "R LINK : " << str << endl;
            }
            else if ( iField == shp_link_next_link ){
                str_temp = str;
                while(str.find(",") != string::npos){
                comma = str.find(",");
                str_temp = str.substr(0, comma);
                link.NLIDS.push_back(str_temp);
                str = str.substr(comma+1);
                }
                link.NLIDS.push_back(str);
                // for(int i =0; i<link.NLIDS.size(); i++)
                // cout<< "NEXT LINK : " << link.NLIDS[i] << endl;
            }
        }

		char *pszWKT = NULL;
		string geometry_str;
        vector<geometry_msgs::Point> link_array;
        OGRGeometry *poGeometry = poFeature->GetGeometryRef();
        if( poGeometry != NULL && wkbFlatten(poGeometry->getGeometryType()) == wkbLineString ) {
           	poGeometry->exportToWkt(&pszWKT);
            geometry_str = pszWKT;
           	//printf("%s\n", pszWKT);
           	CPLFree(pszWKT);
        }
        else {
            printf( "LINK : no point geometry\n" );}
        
        link_array = ParsingLinkGeometry(geometry_str);
        for(int i=0; i<link_array.size(); i++){
            link.geometry.push_back(link_array[i]);
        }
        
		OGRFeature::DestroyFeature( poFeature );
		links.insert(make_pair(link.id, link));
    }

    GDALClose( poDS );
    InitializeRvizLinkArray(LinkGeoVector);

    if(is_link_on)
        LinkArrayPub.publish(LinkArray);
   	// ROS_INFO("Received Links : %d", links.size());
}

vector<geometry_msgs::Point> PLANNING::ParsingLinkGeometry(string geometry_str){

    string str;
    unsigned long comma;
    unsigned long space;

    geometry_msgs::Point point;
    vector<geometry_msgs::Point> point_array;
    
    comma = geometry_str.find("(");
    geometry_str = geometry_str.substr(comma+1);
    
    while(geometry_str.find(",") != string::npos){
        comma = geometry_str.find(",");
        str = geometry_str.substr(0,comma);
        space = str.find(" ");
        point.x = atof(str.substr(0,space).c_str());
        str = str.substr(space+1);
        space = str.find(" ");
        point.y = atof(str.substr(0,space).c_str());
        point_array.push_back(point);
        geometry_str = geometry_str.substr(comma+1);
    }        

    space = geometry_str.find(" ");
    point.x = atof(geometry_str.substr(0,space).c_str());
    geometry_str = geometry_str.substr(space+1);
    space = geometry_str.find(" ");
    point.y = atof(geometry_str.substr(0,space).c_str());
    point_array.push_back(point);

    return point_array;
}

void PLANNING::InitializeRvizLinkArray(vector<geometry_msgs::Point> LinkGeoVector){
    int i = 0;

    LinkArray.markers.resize(links.size());

    for (auto it=links.begin(); it!=links.end(); it++){
        LinkArray.markers[i].header.frame_id = "base_link";
        LinkArray.markers[i].header.stamp = ros::Time::now();
        LinkArray.markers[i].action = visualization_msgs::Marker::ADD;
        LinkArray.markers[i].pose.orientation.w = 1.0;
        LinkArray.markers[i].id = i;
        LinkArray.markers[i].type = visualization_msgs::Marker::LINE_STRIP;
        LinkArray.markers[i].scale.x = 0.3;
        LinkArray.markers[i].color.r = 0.0;
        LinkArray.markers[i].color.g = 1.0;
        LinkArray.markers[i].color.b = 1.0;
        LinkArray.markers[i].color.a = 1.0; 

        LinkArray.markers[i].points.resize(it->second.geometry.size());
        LinkGeoVector.resize(it->second.geometry.size());

        for(int k= 0; k < it->second.geometry.size(); k++){
            LinkGeoVector[k].x = it->second.geometry[k].x - OffsetMapX;
            LinkGeoVector[k].y = it->second.geometry[k].y - OffsetMapY;
            LinkArray.markers[i].points[k] = LinkGeoVector[k];
        }
        LinkGeoVector.clear();
        i++;
    }
}

void PLANNING::GenerateGlobalPath(){

	Node current_node;
	Node goal_node;
	Link current_link;
	Cost current_cost;

	// bool is_new_open_list = false;
    bool is_complete_path = false;

    current_cost = InitializeCost();

    closed_list.clear();
    open_list.clear();
	trajectory_points.clear();
    
    closed_list.push_back(current_cost);
    current_node = nodes.at( start_node_id );
    goal_node = nodes.at( goal_node_id );

    cout << "[START NODE] " << endl << current_node << endl;
    cout << "[GOAL NODE]" << endl << goal_node << endl;

    while( !is_complete_path ){
    	if( current_node.NLIDS[0] != "" ){
    		for( int i = 0; i < current_node.NLIDS.size(); i ++ ){
    			current_link = links.at( current_node.NLIDS[i] );
				Cost temp_cost = CalcCost( current_node, current_link, goal_node );

                UpdataOpenList(temp_cost);

				if( current_link.RLID[0] != "" ){
					for ( int k = 0; k < current_link.RLID.size(); k ++ ){
						// cout << "NEXT RIGHT LINK : " << current_link.RLID[k] << endl;
						Link right_link = links.at( current_link.RLID[k] );
						Cost temp_cost = CalcCost(current_node, current_link, right_link, goal_node);
                        UpdataOpenList(temp_cost);
					}
				}

				if( current_link.LLID[0] != "" ){
					for (int k = 0; k < current_link.LLID.size(); k ++ ){
						// cout << "NEXT LEFT LINK : " << current_link.LLID[k] << endl;
						Link left_link = links.at( current_link.LLID[k] );
						Cost temp_cost = CalcCost(current_node, current_link, left_link, goal_node);
                        UpdataOpenList(temp_cost);

					}
				}
    		}

    	}
    	else  {
			// cout << endl << "<---- Current node has NOT any neighbors!!!! ---->" << endl;  // cout << "current node id : " << current_node.id << endl << endl;
		}

		// cout << "<Closed list>" << endl;
		// for( int k = 0; k < closed_list.size(); k ++ )
		// 	printf( "%s ", closed_list[k].node.c_str() );

		// cout<< endl << "<Open list>" << endl;
		// for(int k = 0; k < open_list.size(); k ++ )
		// 	printf( "%s ", open_list[k].node.c_str() );
		// cout<< "----------------------------------------" << endl << endl;

		float min_score = 999999;
		unsigned int path_candidate = 0;	

		for( int i = 0; i < open_list.size(); i ++ ){
			if( open_list[i].f_score < min_score ){
				min_score = open_list[i].f_score;
				// cout << "min score :  " << min_score << " id : " << open_list[i].node << endl;
				path_candidate = i;
			}
			// cout << i <<" : " <<  "min score :  " << min_score << " id : " << open_list[path_candidate].node << endl;
		}
        // cout << "min score :  " << min_score << " id : " << open_list[path_candidate].node << endl;

		closed_list.push_back( open_list[path_candidate] );
		open_list.erase( open_list.begin() + path_candidate );

		current_node = nodes.at( closed_list.back().node );

		if( closed_list.back().node == goal_node.id )
		    is_complete_path = true;
    }

    GenerateWayPoint( closed_list );
}

void PLANNING::UpdataOpenList(Cost temp_cost){

    bool is_new_open_list = false;

    for( int j = 0; j < closed_list.size(); j ++ ){
        if(temp_cost.node == closed_list[j].node && temp_cost.parent_node == closed_list[j].parent_node){
            is_new_open_list = false;
            // cout << "This node is already in the closed list!!! -> " << temp_cost.node << " & " << closed_list[j].node << " " << temp_cost.parent_node <<" & " << closed_list[j].parent_node <<endl << endl;
            break;  
        }
        else
            is_new_open_list = true;
    }

    if( is_new_open_list ){
        open_list.push_back(temp_cost);

        for( int j = 0; j < open_list.size() - 1; j ++ ){
            if(temp_cost.node == open_list[j].node && temp_cost.parent_node == open_list[j].parent_node ){
                // cout << endl << "There is same node in the open list!" << endl;
                if( temp_cost.g_score < open_list[j].g_score ){
                open_list[j].g_score = temp_cost.g_score;
                open_list[j].f_score = temp_cost.f_score;
                open_list[j].parent_node = temp_cost.parent_node;
                open_list[j].link = temp_cost.link;
                }
                open_list.pop_back();
            }
        }
    }
}

void PLANNING::GenerateWayPoint(vector<Cost> closed_list){
    
    trajectory_node.clear();
    trajectory_link.clear();
    string parent_id;

    for( int i=closed_list.size()-1; i > 0; i-- ){
        if(i == closed_list.size()-1){
            trajectory_node.push_back(closed_list[i].node);
            parent_id = closed_list[i].parent_node;
            trajectory_link.push_back(closed_list[i].link);
            // cout << closed_list[i].node_id << "  " << closed_list[i].parent_node_id <<endl;
        }
        else{
            if(parent_id == closed_list[i].node){
                trajectory_node.push_back(closed_list[i].node);
                parent_id = closed_list[i].parent_node;
                trajectory_link.push_back(closed_list[i].link);
            }
        }
    }

    trajectory_node.push_back(parent_id);

    reverse(trajectory_node.begin(), trajectory_node.end());
    reverse(trajectory_link.begin(), trajectory_link.end());

    cout << endl << "Global Path Node : " << endl;
    for(int i=0; i<trajectory_node.size(); i++) cout<< trajectory_node[i] << endl; 

    cout << endl << "Global Path Link : " << endl;
    for(int i=0; i<trajectory_link.size(); i++) cout<< trajectory_link[i] << endl;

    Node waypoint;
    Link waypoint_link;
    Link waypoint_near_link;
    
    geometry_msgs::Point temp; 

    for(int i=0; i<trajectory_node.size()-1 ; i++){
        waypoint = nodes.at(trajectory_node[i]);
        waypoint_link = links.at(trajectory_link[i]);

        for(int j=0; j<waypoint.NLIDS.size(); j++){
            if(waypoint.NLIDS[j] == trajectory_link[i]){
                is_lane_changed = false;                
                break;
            }
            else{
                is_lane_changed = true;                

                if(waypoint.NLIDS[j] == waypoint_link.LLID[0]){
                    waypoint_near_link = links.at(waypoint_link.LLID[0]);
                }
                else if(waypoint.NLIDS[j] == waypoint_link.RLID[0]){
                    waypoint_near_link = links.at(waypoint_link.RLID[0]);
                }
            }
        }
        if(i==0){
            GenerateStartPoint(is_lane_changed);
        }

        if (i < trajectory_node.size()-2 && i > 0 ){
            if(is_lane_changed) {
                vector<geometry_msgs::Point> curve_points = GenerateCurvePoint(waypoint_near_link, waypoint_link);
                for (int j=0; j<curve_points.size(); j++){
                    temp.x = curve_points[j].x - OffsetMapX;
                    temp.y = curve_points[j].y - OffsetMapY;
                    trajectory_points.push_back(temp);
                }
            }
            else{      
                for(int j=0; j<waypoint_link.geometry.size(); j++){
                    temp.x = waypoint_link.geometry[j].x - OffsetMapX;
                    temp.y = waypoint_link.geometry[j].y - OffsetMapY;   
                    trajectory_points.push_back(temp);
                }
            }
        }
        // cout << "is lane chanege? " << is_lane_changed << " node: " << trajectory_node[i] << endl;
    }
}

void PLANNING::DrawingPath(){
    PathArray.header.frame_id = "base_link";
    PathArray.header.stamp = ros::Time::now();
    PathArray.action = visualization_msgs::Marker::ADD;
    PathArray.pose.orientation.w = 1.0;
    PathArray.id = 1;
    PathArray.type = visualization_msgs::Marker::LINE_STRIP;
    PathArray.scale.x = 0.8;
    PathArray.color.g = 1.0;
    PathArray.color.b = 0.5;
    PathArray.color.a = 1.0;

    PathArray.points.clear();
    for(int i=0; i<trajectory_points.size(); i++)   
        PathArray.points.push_back(trajectory_points[i]);

    if(is_path_on){
        PathArrayPub.publish(PathArray);
    }
}

vector<geometry_msgs::Point> PLANNING::GenerateCurvePoint(Link prev_link, Link waypoint_link){

    geometry_msgs::Point P1, P2, P3, P4;
    geometry_msgs::Point temp;
    geometry_msgs::Point start_point;
    double refer_length = prev_link.length / 2;
    int w = 0;
    bool is_P1 = false;
    int idx_p1 = 0;
    double dist=0;

    for(int i=0; i<prev_link.geometry.size(); i++){
        if(i==0){
            start_point.x = prev_link.geometry[i].x;
            start_point.y = prev_link.geometry[i].y;
        }
        else{
            dist += GetDistance(prev_link.geometry[i].x, prev_link.geometry[i].y, prev_link.geometry[i-1].x, prev_link.geometry[i-1].y);
            if(prev_link.length > 50){
                if (!is_P1){
                    if ( dist > (prev_link.length -50)/2 ){
                        idx_p1 = i;
                        is_P1 = true;
                    }
                }
            }
            if(dist > refer_length){
                w = i;
                break;
            }
        }
    }

    P1 = prev_link.geometry[idx_p1];
    P2 = prev_link.geometry[w];
    P3 = waypoint_link.geometry[waypoint_link.geometry.size() - w + 1];
    P4 = waypoint_link.geometry[waypoint_link.geometry.size()-1 - idx_p1];

    vector<geometry_msgs::Point> curve_points;
    geometry_msgs::Point bezier;

    if(is_P1){
        for(int i=0; i<idx_p1; i++){
            curve_points.push_back(prev_link.geometry[i]);
        }
    }

    double new_points_size = 20.0;
    for(int t=0; t < new_points_size; t++){
        double s = ((double) t)/new_points_size;
        bezier.x = P1.x * pow((1-s),3) + 3 * P2.x * s * pow(1-s, 2) + 3 * P3.x * pow(s, 2) * (1-s) + P4.x * pow(s, 3);
        bezier.y = P1.y * pow((1-s),3) + 3 * P2.y * s * pow(1-s, 2) + 3 * P3.y * pow(s, 2) * (1-s) + P4.y * pow(s, 3);

        curve_points.push_back(bezier);
    }
    if(is_P1){
        for(int i=waypoint_link.geometry.size()- idx_p1; i<waypoint_link.geometry.size(); i++){
            curve_points.push_back(waypoint_link.geometry[i]);
        }
    }
    return curve_points;
}

Cost PLANNING::InitializeCost(){
	Cost current_cost;
	current_cost.node = start_node_id;
    current_cost.g_score = 0;
    current_cost.h_score = 0;
    current_cost.f_score = 0;
    current_cost.parent_node = "NONE";
    current_cost.link = "NONE";

    return current_cost;
}


Cost PLANNING::CalcCost(Node current_node, Link current_link, Node goal_node){

	Node next_node = nodes.at(current_link.to_node);

	float g_score = current_link.length;
	float h_score = GetDistance(next_node.geometry.x, next_node.geometry.y, goal_node.geometry.x, goal_node.geometry.y);
	float f_score = g_score + h_score;

	cout<< "parent node: [" << current_node.id << "] " << " currnet link : [" << current_link.id << "]" << " next node : [" << next_node.id << "]"<< endl; 
	cout << "g: " << g_score << " h: " << h_score << " f: " << f_score << endl << endl;

	Cost temp_cost;
	temp_cost.node = next_node.id;
	temp_cost.g_score = g_score;
	temp_cost.h_score = h_score;
	temp_cost.f_score = f_score;
	temp_cost.parent_node = current_node.id;
	temp_cost.link = current_link.id;

	return temp_cost;
}

Cost PLANNING::CalcCost(Node current_node, Link current_link, Link lrlink, Node goal_node){

	Node next_node = nodes.at( lrlink.to_node );
	// double weight = 4.0;

	float g_score = current_link.length * weight ; //GetDistance(next_node.geometry.x, next_node.geometry.y, current_node.geometry.x, current_node.geometry.y);
	float h_score = GetDistance(next_node.geometry.x, next_node.geometry.y, goal_node.geometry.x, goal_node.geometry.y);
	float f_score = g_score + h_score;

	cout<< "parent node: [" << current_node.id << "] " << " currnet link : [" << lrlink.id << "]" << " next node : [" << next_node.id << "]"<< endl; 
	cout << "g: " << g_score << " h: " << h_score << " f: " << f_score << endl << endl;

	Cost temp_cost;
	temp_cost.node = next_node.id;
	temp_cost.g_score = g_score * weight;
	temp_cost.h_score = h_score;
	temp_cost.f_score = f_score;
	temp_cost.parent_node = current_node.id;
	temp_cost.link = lrlink.id;

	return temp_cost;
}

float PLANNING::GetDistance(float pCurrent_x, float pCurrent_y, float pNext_x, float pNext_y){
	float Distance = sqrt(pow(pNext_x - pCurrent_x, 2) + pow(pNext_y - pCurrent_y, 2));
	return Distance;
}

// This function is to use for the Vehicle with GPS
void PLANNING::GpsCallback(const sensor_msgs::NavSatFixConstPtr& fix){

    double northing, easting;
    string zone;
    int flag=0;

    if(fix->status.status == sensor_msgs::NavSatStatus::STATUS_NO_FIX){
        ROS_INFO("No Fix.");
        return;
    }

    if(fix->header.stamp == ros::Time(0)){
        return;
    }

    LLtoUTM(fix->latitude, fix->longitude, northing, easting, zone);

    if(flag ==0){
        OffsetGps.x = easting;
        OffsetGps.y = northing;
    }

    VehiclePosition.x = easting - OffsetGps.x;
    VehiclePosition.y = northing - OffsetGps.y;
    VehiclePosition.z = 0;
}

void PLANNING::GpsHeadingCallback(const ublox_msgs::NavPVTConstPtr& navheading){
    NavheadingValueDeg = navheading->heading * 0.00001;
    NavheadingValueDeg = -(NavheadingValueDeg - 90);
    NavheadingValueRad = (NavheadingValueDeg * math_pi) / 180;
}

void PLANNING::VehicleClosestLink(geometry_msgs::Point VehiclePosition){
    double Dist, DiffTheta;
    double yaw;
    double dist_threshold = 3;
    double slope, intersect, dist2link;
    double mindist2link = 1000.0;
    int count = 0;
    int index;
    string previd = "abc";
    string minLinkId;
    vector<pair<string,geometry_msgs::Point>> GeometryPair;
    vector<pair<string,geometry_msgs::Point>> candidate_link;
    geometry_msgs::Point GeometryPoints;
    geometry_msgs::Point minLinkGeometry;

    yaw = NavheadingValueRad;

    for (auto it=links.begin(); it!=links.end(); it++){
        count = count + it->second.geometry.size();
        for(auto jt=it->second.geometry.begin(); jt!=it->second.geometry.end(); jt++){
            GeometryPoints.x = jt->x - OffsetMapX;
            GeometryPoints.y = jt->y - OffsetMapY;
            GeometryPoints.z = jt->z;
            GeometryPair.push_back(pair<string,geometry_msgs::Point>(it->first,GeometryPoints));
        }
    }

    while(candidate_link.size() < 2){
        candidate_link.clear();
        for (int i=0; i<GeometryPair.size(); i++){
            Dist = GetDistance(VehiclePosition.x, VehiclePosition.y, GeometryPair[i].second.x, GeometryPair[i].second.y);
            if (Dist < dist_threshold){
                DiffTheta = yaw - atan2(GeometryPair[i].second.y - VehiclePosition.y, GeometryPair[i].second.x - VehiclePosition.x);
                if(abs(DiffTheta) < math_pi/2){
                    index = i;
                    candidate_link.push_back(GeometryPair[index]);
                }
            }
        }
        dist_threshold = dist_threshold + 0.5;
    }

    for(int i=0; i<candidate_link.size(); i++){
        if(previd != candidate_link[i].first){
            previd = candidate_link[i].first;
        }
        else{
            slope = GetSlope(candidate_link[i-1].second,candidate_link[i].second);
            intersect = GetIntersectY(slope, candidate_link[i].second);
            dist2link = abs(slope * VehiclePosition.x + (-1) * VehiclePosition.y + intersect) / sqrt(pow(slope,2) + pow(1,2));

            if(dist2link < mindist2link){
                mindist2link = dist2link;
                minLinkId = candidate_link[i].first;
                minLinkGeometry = candidate_link[i].second;
                StartLinkSlope = slope;

                cout << "---------------------------" <<endl;
                cout << "ID: " << minLinkId <<endl;
                cout << "Dist: " << mindist2link <<endl;
                cout << "Geo: " << minLinkGeometry <<endl;
            }
        }
    }

}

// These Functions are to test in Rviz Simulation.
void PLANNING::RvizClosestStartLink(geometry_msgs::Pose RvizPosition){
    cout << "Searching closest start link..." << endl;
    double Dist, DiffTheta;
    double siny_cosp, cosy_cosp, yaw;
    double dist_threshold = 3;
    double slope, intersect, dist2link;
    double mindist2link = 1000.0;
    int count = 0;
    int index;
    string previd = "abc";
    string minLinkId;
    vector<pair<string,geometry_msgs::Point>> GeometryPair;
    vector<pair<string,geometry_msgs::Point>> candidate_link;
    geometry_msgs::Point GeometryPoints;
    geometry_msgs::Point minLinkGeometry;
    //---

    siny_cosp = 2* (RvizPosition.orientation.w * RvizPosition.orientation.z + RvizPosition.orientation.x * RvizPosition.orientation.y);
    cosy_cosp = 1 - 2 * (RvizPosition.orientation.y * RvizPosition.orientation.y + RvizPosition.orientation.z * RvizPosition.orientation.z);
    yaw = atan2(siny_cosp, cosy_cosp);


    for (auto it=links.begin(); it!=links.end(); it++){
        cout << "id: " << it->first << endl;
        count = count + it->second.geometry.size();
        for(auto jt=it->second.geometry.begin(); jt!=it->second.geometry.end(); jt++){
            GeometryPoints.x = jt->x - OffsetMapX;
            GeometryPoints.y = jt->y - OffsetMapY;
            GeometryPoints.z = jt->z;
            GeometryPair.push_back(pair<string,geometry_msgs::Point>(it->first,GeometryPoints));
        }
    }
    while(candidate_link.size() < 2){
        candidate_link.clear();
        for (int i=0; i<GeometryPair.size(); i++){
            Dist = GetDistance(RvizPosition.position.x, RvizPosition.position.y, GeometryPair[i].second.x, GeometryPair[i].second.y);
            if (Dist < dist_threshold){
                DiffTheta = yaw - atan2(GeometryPair[i].second.y - RvizPosition.position.y, GeometryPair[i].second.x - RvizPosition.position.x);
                if(abs(DiffTheta) < math_pi/2){
                    index = i;
                    candidate_link.push_back(GeometryPair[index]);
                }
            }
        }
        dist_threshold = dist_threshold + 0.5;
    }
    cout << "Here3..." << endl;
    for(int i=0; i<candidate_link.size(); i++){
        if(previd != candidate_link[i].first){
            previd = candidate_link[i].first;
        }
        else{
            slope = GetSlope(candidate_link[i-1].second,candidate_link[i].second);
            intersect = GetIntersectY(slope, candidate_link[i].second);
            dist2link = abs(slope * RvizPosition.position.x + (-1) * RvizPosition.position.y + intersect) / sqrt(pow(slope,2) + pow(1,2));

            if(dist2link < mindist2link){
                mindist2link = dist2link;
                minLinkId = candidate_link[i].first;
                minLinkGeometry = candidate_link[i].second;
                StartLinkSlope = slope;

                cout << "---------------------------" <<endl;
                cout << "ID: " << minLinkId <<endl;
                cout << "Dist: " << mindist2link <<endl;
                cout << "Geo: " << minLinkGeometry <<endl;
                cout << "End------------------------" <<endl;
            }
        }
    }

    ClosestStartLinkId = minLinkId;
    ClosestStartLinkGeo = minLinkGeometry;
    
}

void PLANNING::RvizClosestEndLink(geometry_msgs::Pose RvizGoal){
    cout << "Searching closest goal link..." << endl;
    double Dist, DiffTheta;
    double siny_cosp, cosy_cosp, yaw;
    double dist_threshold = 3;
    double slope, intersect, dist2link;
    double mindist2link = 1000.0;
    int count = 0;
    int index;
    string previd = "abc";
    string minLinkId;
    vector<pair<string,geometry_msgs::Point>> GeometryPair;
    vector<pair<string,geometry_msgs::Point>> candidate_link;
    geometry_msgs::Point GeometryPoints;
    geometry_msgs::Point minLinkGeometry;
    //---

    siny_cosp = 2* (RvizGoal.orientation.w * RvizGoal.orientation.z + RvizGoal.orientation.x * RvizGoal.orientation.y);
    cosy_cosp = 1 - 2 * (RvizGoal.orientation.y * RvizGoal.orientation.y + RvizGoal.orientation.z * RvizGoal.orientation.z);
    yaw = atan2(siny_cosp, cosy_cosp);


    for (auto it=links.begin(); it!=links.end(); it++){
        count = count + it->second.geometry.size();
        for(auto jt=it->second.geometry.begin(); jt!=it->second.geometry.end(); jt++){
            GeometryPoints.x = jt->x - OffsetMapX;
            GeometryPoints.y = jt->y - OffsetMapY;
            GeometryPoints.z = jt->z;
            GeometryPair.push_back(pair<string,geometry_msgs::Point>(it->first,GeometryPoints));
        }
    }

    while(candidate_link.size() < 2){
        candidate_link.clear();
        for (int i=0; i<GeometryPair.size(); i++){
            Dist = GetDistance(RvizGoal.position.x, RvizGoal.position.y, GeometryPair[i].second.x, GeometryPair[i].second.y);
            if (Dist < dist_threshold){
                DiffTheta = yaw - atan2(GeometryPair[i].second.y - RvizGoal.position.y, GeometryPair[i].second.x - RvizGoal.position.x);
                if(abs(DiffTheta) < math_pi/2){
                    index = i;
                    candidate_link.push_back(GeometryPair[index]);
                }
            }
        }
        dist_threshold = dist_threshold + 0.5;
    }

    for(int i=0; i<candidate_link.size(); i++){
        if(previd != candidate_link[i].first){
            previd = candidate_link[i].first;
        }
        else{
            slope = GetSlope(candidate_link[i-1].second,candidate_link[i].second);
            intersect = GetIntersectY(slope, candidate_link[i].second);
            dist2link = abs(slope * RvizGoal.position.x + (-1) * RvizGoal.position.y + intersect) / sqrt(pow(slope,2) + pow(1,2));

            if(dist2link < mindist2link){
                mindist2link = dist2link;
                minLinkId = candidate_link[i].first;
                minLinkGeometry = candidate_link[i].second;
                EndLinkSlope = slope;

                cout << "---------------------------" <<endl;
                cout << "ID: " << minLinkId <<endl;
                cout << "Dist: " << mindist2link <<endl;
                cout << "Geo: " << minLinkGeometry <<endl;
                cout << "End------------------------" <<endl;
            }
        }
    }

    ClosestEndLinkId = minLinkId;
    ClosestEndLinkGeo = minLinkGeometry;
}

double PLANNING::GetSlope(geometry_msgs::Point a, geometry_msgs::Point b){
    double slope;
    slope = (b.y - a.y) / (b.x - a.x);
    return slope;
}

double PLANNING::GetIntersectY(double slope, geometry_msgs::Point a){
    double intersect;
    intersect = -(slope * a.x) + a.y;
    return intersect;
}

void PLANNING::RvizPoseEstimateCallback(const geometry_msgs::PoseWithCovarianceStamped &PoseEstimate){
    RvizPosition.position.x = PoseEstimate.pose.pose.position.x;
    RvizPosition.position.y = PoseEstimate.pose.pose.position.y;
    RvizPosition.position.z = 0;

    RvizPosition.orientation.x = PoseEstimate.pose.pose.orientation.x;
    RvizPosition.orientation.y = PoseEstimate.pose.pose.orientation.y;
    RvizPosition.orientation.z = PoseEstimate.pose.pose.orientation.z;
    RvizPosition.orientation.w = PoseEstimate.pose.pose.orientation.w;

    RvizClosestStartLink(RvizPosition);
    start_node_id = links.at(ClosestStartLinkId).from_node;
}

void PLANNING::RvizNavGoalCallback(const geometry_msgs::PoseStamped &NavGoal){
    RvizGoal.position.x = NavGoal.pose.position.x;
    RvizGoal.position.y = NavGoal.pose.position.y;
    RvizGoal.position.z = 0;

    RvizGoal.orientation.x = NavGoal.pose.orientation.x;
    RvizGoal.orientation.y = NavGoal.pose.orientation.y;
    RvizGoal.orientation.z = NavGoal.pose.orientation.z;
    RvizGoal.orientation.w = NavGoal.pose.orientation.w;

    RvizClosestEndLink(RvizGoal);
    goal_node_id = links.at(ClosestEndLinkId).to_node;

    GenerateGlobalPath();
    GenerateGoalPoint();
    DrawingPath();

    // VehicleClosestLink(VehiclePosition);
}

// void PLANNING::GenerateGoalPoint(){

//     cout << "Generate Goal Point..." << endl;

//     // goal_points.clear();

//     // cout <<" closest link : " << ClosestEndLinkId << endl;
//     Link goal_link = links.at(ClosestEndLinkId);

//     // vector<geometry_msgs::Point> points;
//     geometry_msgs::Point temp;
//     geometry_msgs::Point P1, P2, P3, P4;
//     int w = 0;
//     double min_dist = 9999;
//     double dist ;
//     int min_idx = 0;

//     for(int i=0; i<goal_link.geometry.size(); i++){

//         temp.x = goal_link.geometry[i].x - OffsetMapX;
//         temp.y = goal_link.geometry[i].y - OffsetMapY;

//         dist  = GetDistance(RvizGoal.position.x, RvizGoal.position.y, temp.x, temp.y);

//         if ( min_dist > dist ){
//             min_dist = dist;
//             min_idx = i;
//         }
//         // cout << "dist : " << dist << " min : " << min_dist << " min_idx : " << min_idx << " size : "<< goal_link.geometry.size() << endl;
//     }

//     Link prev_link;

//     double refer_length = GetDistance(goal_link.geometry[min_idx].x, goal_link.geometry[min_idx].y, goal_link.geometry[0].x, goal_link.geometry[0].y) / 2;

//     for(int i=0; i<goal_link.geometry.size(); i++){
//         if ( GetDistance(goal_link.geometry[i].x, goal_link.geometry[i].y, goal_link.geometry[0].x, goal_link.geometry[0].y) > refer_length ){
//             w = i;
//             break;
//         }
//     }

//     if (is_lane_changed){
//         if (links.at(trajectory_link.back()).LLID[0]!=""){
//             prev_link = links.at(links.at(trajectory_link.back()).LLID[0]);

//         }
//         else if(links.at(trajectory_link.back()).RLID[0]!=""){            
//             prev_link = links.at(links.at(trajectory_link.back()).RLID[0]);
//         }

//         // cout <<"lane : " << is_lane_changed << " min_idx " << min_idx << " w :" << w << endl;

//         P1.x = prev_link.geometry[0].x - OffsetMapX;
//         P1.y = prev_link.geometry[0].y - OffsetMapY;
        
//         P2.x = prev_link.geometry[w].x - OffsetMapX;
//         P2.y = prev_link.geometry[w].y - OffsetMapY;

//         P3.x = goal_link.geometry[w].x - OffsetMapX;
//         P3.y = goal_link.geometry[w].y - OffsetMapY;

//         P4.x = goal_link.geometry[min_idx].x - OffsetMapX;
//         P4.y = goal_link.geometry[min_idx].y - OffsetMapY;
        
//         // P4 = RvizGoal.position;

//         // cout << "P1: " << endl << P1 << endl;
//         // cout << "P2: " << endl << P2 << endl;
//         // cout << "P3: " << endl << P3 << endl;
//         // cout << "P4: " << endl << P4 << endl;
    
    
//         geometry_msgs::Point bezier;

//         double new_points_size = 20.0;

//         for(int t=0; t < new_points_size; t++){
//             // double s = ((double) t)/new_points_size;
//             // bezier.x = pow((1-s),2) * P1.x + 2 * s * (1-s) * P2.x + pow(s,2) * P3.x;
//             // bezier.y = pow((1-s),2) * P1.y + 2 * s * (1-s) * P2.y + pow(s,2) * P3.y;
//             // goal_points.push_back(bezier);

//             double s = ((double) t)/new_points_size;
//             bezier.x = P1.x * pow((1-s),3) + 3 * P2.x * s * pow(1-s, 2) + 3 * P3.x * pow(s, 2) * (1-s) + P4.x * pow(s, 3);
//             bezier.y = P1.y * pow((1-s),3) + 3 * P2.y * s * pow(1-s, 2) + 3 * P3.y * pow(s, 2) * (1-s) + P4.y * pow(s, 3);
//             // cout << "bezier : " << bezier.x << "  " << bezier.y << endl;

//             // goal_points.push_back(bezier);
//             trajectory_points.push_back(bezier);
//         }
//     }
//     else {
//         // cout <<"lane : " << is_lane_changed << " min_idx " << min_idx << " w :" << w << endl;
//         for(int i = 0; i < min_idx+1 ; i++){
//             temp.x = goal_link.geometry[i].x - OffsetMapX;
//             temp.y = goal_link.geometry[i].y - OffsetMapY;
//             // cout << "i : " << i << endl;
//             // goal_points.push_back(temp);
//             trajectory_points.push_back(temp);
//         }    
//     }
    

// }

void PLANNING::GenerateGoalPoint(){

    cout << "Generate Goal Point..." << endl;
    Link goal_link = links.at(ClosestEndLinkId);

    geometry_msgs::Point temp;
    geometry_msgs::Point P1, P2, P3, P4;
    int w = 0;
    double min_dist = 9999;
    double dist2goal;
    double dist_sum=0;
    int min_idx = 0;
    // double refer_length = goal_link.length;
    Link prev_link;
    double dist;

    for(int i=0; i<goal_link.geometry.size(); i++){
        temp.x = goal_link.geometry[i].x - OffsetMapX;
        temp.y = goal_link.geometry[i].y - OffsetMapY;

        dist  = GetDistance(RvizGoal.position.x, RvizGoal.position.y, temp.x, temp.y);
        if ( min_dist > dist ){
            min_dist = dist;
            min_idx = i;
        }
        // cout << "dist : " << dist << " min : " << min_dist << " min_idx : " << min_idx << " size : "<< goal_link.geometry.size() << endl;
    }

    double refer_length = GetDistance(goal_link.geometry[min_idx].x, goal_link.geometry[min_idx].y, goal_link.geometry[0].x, goal_link.geometry[0].y) / 2;
    for(int i=0; i<goal_link.geometry.size(); i++){
        if ( GetDistance(goal_link.geometry[i].x, goal_link.geometry[i].y, goal_link.geometry[0].x, goal_link.geometry[0].y) > refer_length ){
            w = i;
            break;
        }
    }

    // for(int i=0; i<goal_link.geometry.size(); i++){
    //     temp.x = goal_link.geometry[i].x - OffsetMapX;
    //     temp.y = goal_link.geometry[i].y - OffsetMapY;
    //     if(i>0){
    //         dist_sum += GetDistance(goal_link.geometry[i].x, goal_link.geometry[i].y, goal_link.geometry[i-1].x, goal_link.geometry[i-1].y);
    //     }
    //     dist2goal  = GetDistance(RvizGoal.position.x, RvizGoal.position.y, temp.x, temp.y);
    //     if ( min_dist > dist2goal ){
    //         min_dist = dist2goal;
    //         min_idx = i;
    //         refer_length = dist_sum/2;
    //     }
    // }

    // dist_sum = 0;

    // for(int i = 1; i < goal_link.geometry.size(); i++){
    //     dist_sum += GetDistance(goal_link.geometry[i].x, goal_link.geometry[i].y, goal_link.geometry[i-1].x, goal_link.geometry[i-1].y);
    //     if(dist_sum > refer_length){
    //         w = i;
    //         break;
    //     }
    // }

    if (is_lane_changed){
        if (links.at(trajectory_link.back()).LLID[0]!=""){
            prev_link = links.at(links.at(trajectory_link.back()).LLID[0]);

        }
        else if(links.at(trajectory_link.back()).RLID[0]!=""){            
            prev_link = links.at(links.at(trajectory_link.back()).RLID[0]);
        }

        P1.x = prev_link.geometry[0].x - OffsetMapX;
        P1.y = prev_link.geometry[0].y - OffsetMapY;
        
        P2.x = prev_link.geometry[w].x - OffsetMapX;
        P2.y = prev_link.geometry[w].y - OffsetMapY;

        P3.x = goal_link.geometry[w].x - OffsetMapX;
        P3.y = goal_link.geometry[w].y - OffsetMapY;

        P4.x = goal_link.geometry[min_idx].x - OffsetMapX;
        P4.y = goal_link.geometry[min_idx].y - OffsetMapY;
        
        geometry_msgs::Point bezier;

        double new_points_size = 20.0;

        for(int t=0; t < new_points_size; t++){

            double s = ((double) t)/new_points_size;
            bezier.x = P1.x * pow((1-s),3) + 3 * P2.x * s * pow(1-s, 2) + 3 * P3.x * pow(s, 2) * (1-s) + P4.x * pow(s, 3);
            bezier.y = P1.y * pow((1-s),3) + 3 * P2.y * s * pow(1-s, 2) + 3 * P3.y * pow(s, 2) * (1-s) + P4.y * pow(s, 3);
            cout << "bezier : " << bezier.x << "  " << bezier.y << endl;
            trajectory_points.push_back(bezier);
        }
    }
    else {
        for(int i = 0; i < min_idx+1 ; i++){
            temp.x = goal_link.geometry[i].x - OffsetMapX;
            temp.y = goal_link.geometry[i].y - OffsetMapY;
            trajectory_points.push_back(temp);
        }    
    }
}

void PLANNING::GenerateStartPoint(bool is_lane_changed){

    cout << "Generate Start Point..." << endl;

    Link start_link = links.at(ClosestStartLinkId);
    geometry_msgs::Point P1, P2, P3, P4;

    geometry_msgs::Point temp;

    double min_dist = 9999;
    double dist ;
    int min_idx = 0;
    int w = 0;
    Link prev_link;

    for(int i=0; i<start_link.geometry.size(); i++){
        temp.x = start_link.geometry[i].x - OffsetMapX;
        temp.y = start_link.geometry[i].y - OffsetMapY;
        dist  = GetDistance(RvizPosition.position.x , RvizPosition.position.y, temp.x, temp.y);
        if ( min_dist > dist ){
            min_dist = dist;
            min_idx = i;
        }    
    }
    double refer_length = GetDistance(start_link.geometry[min_idx].x, start_link.geometry[min_idx].y, start_link.geometry.back().x, start_link.geometry.back().y) / 2;

    for(int i=0; i<start_link.geometry.size(); i++){
        if ( GetDistance(start_link.geometry[i].x, start_link.geometry[i].y, start_link.geometry.back().x, start_link.geometry.back().y) < refer_length ){
            w = i;
            break;
        }
    }

    if (is_lane_changed){

        if (start_link.LLID[0]!=""){

            prev_link = links.at(links.at(ClosestStartLinkId).LLID[0]);
            cout << "prev_link1 left" << prev_link.id << endl; 

        }
        else if(start_link.RLID[0]!=""){            
            prev_link = links.at(links.at(ClosestStartLinkId).RLID[0]);
            cout << "prev_link2 left" << prev_link.id << endl;
        }

        cout <<"lane : " << is_lane_changed << " min_idx " << min_idx << " w :" << w << endl;

        P1.x = start_link.geometry[min_idx].x - OffsetMapX;
        P1.y = start_link.geometry[min_idx].y - OffsetMapY;

        cout << "here1" << endl;

        P2.x = start_link.geometry[w].x - OffsetMapX;
        P2.y = start_link.geometry[w].y - OffsetMapY;
        cout << "here2" << endl;

        P3.x = prev_link.geometry[w].x - OffsetMapX;
        P3.y = prev_link.geometry[w].y - OffsetMapY;
        cout << "here3" << endl;
        P4.x = prev_link.geometry.back().x - OffsetMapX;
        P4.y = prev_link.geometry.back().y - OffsetMapY;
        
        cout << "P1: " << endl << P1 << endl;
        cout << "P2: " << endl << P2 << endl;
        cout << "P3: " << endl << P3 << endl;
        cout << "P4: " << endl << P4 << endl;

        geometry_msgs::Point bezier;

        double new_points_size = 20.0;

        for(int t=0; t < new_points_size; t++){

            double s = ((double) t)/new_points_size;
            bezier.x = P1.x * pow((1-s),3) + 3 * P2.x * s * pow(1-s, 2) + 3 * P3.x * pow(s, 2) * (1-s) + P4.x * pow(s, 3);
            bezier.y = P1.y * pow((1-s),3) + 3 * P2.y * s * pow(1-s, 2) + 3 * P3.y * pow(s, 2) * (1-s) + P4.y * pow(s, 3);
            cout << "bezier : " << bezier.x << "  " << bezier.y << endl;

            trajectory_points.push_back(bezier);
        }
    }
    else {
        for(int i = min_idx; i < start_link.geometry.size() ; i++){
            temp.x = start_link.geometry[i].x - OffsetMapX;
            temp.y = start_link.geometry[i].y - OffsetMapY;
            trajectory_points.push_back(temp);
        }    
    }
}
